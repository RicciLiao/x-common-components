package ricciliao.common.component.als;

import hk.health.medication.als.logger.AlsGeneralLogger;

public class AlsLoggerFactory {

    private final AlsLoggerRegistry alsLoggerRegistry;

    private static AlsGeneralLogger alsGeneralLogger;

    public AlsLoggerFactory(AlsLoggerRegistry alsLoggerRegistry) {
        this.alsLoggerRegistry = alsLoggerRegistry;
    }

    public AlsLoggerRegistry getAlsLoggerRegistry() {
        return alsLoggerRegistry;
    }

    public static AlsGeneralLogger getAlsGeneralLogger() {
        return alsGeneralLogger;
    }

    static void buildAlsGeneralLogger(AlsLoggerRegistry alsLoggerRegistry){
        alsGeneralLogger = new AlsGeneralLogger(alsLoggerRegistry);
    }

}