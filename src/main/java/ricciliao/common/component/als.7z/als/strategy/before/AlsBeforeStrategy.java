package ricciliao.common.component.als.strategy.before;

import hk.health.medication.als.AlsLoggerRegistry;
import hk.health.medication.als.pojo.AlsStrategyBo;
import hk.health.medication.als.strategy.AlsAspectStrategy;
import org.aspectj.lang.JoinPoint;

public abstract class AlsBeforeStrategy<T> extends AlsAspectStrategy<T> {

    public AlsBeforeStrategy(AlsLoggerRegistry alsLoggerRegistry) {
        super(alsLoggerRegistry);
    }

    protected abstract String getMethodDescription(AlsStrategyBo alsStrategy, JoinPoint joinPoint);

    protected abstract String getMethodArgs(AlsStrategyBo alsStrategy, JoinPoint joinPoint);

    @Override
    protected String getDescription(AlsStrategyBo alsStrategy, JoinPoint joinPoint, T data) {
        return this.getMethodDescription(alsStrategy, joinPoint);
    }

    @Override
    protected String getContent(AlsStrategyBo alsStrategy, JoinPoint joinPoint, T data) {
        return this.getMethodArgs(alsStrategy, joinPoint);
    }

}
