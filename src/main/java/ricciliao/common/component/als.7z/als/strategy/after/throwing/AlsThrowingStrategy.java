package ricciliao.common.component.als.strategy.after.throwing;

import hk.health.medication.als.AlsLoggerRegistry;
import hk.health.medication.als.pojo.AlsStrategyBo;
import hk.health.medication.als.strategy.AlsAspectStrategy;
import org.aspectj.lang.JoinPoint;

public abstract class AlsThrowingStrategy extends AlsAspectStrategy<Throwable> {

    public AlsThrowingStrategy(AlsLoggerRegistry alsLoggerRegistry) {
        super(alsLoggerRegistry);
    }

    protected abstract String getMethodDescription(AlsStrategyBo alsStrategy, JoinPoint joinPoint, Throwable throwable);

    protected abstract String getThrowable(AlsStrategyBo alsStrategy, JoinPoint joinPoint, Throwable throwable);

    @Override
    protected String getDescription(AlsStrategyBo alsStrategy, JoinPoint joinPoint, Throwable throwable) {
        return this.getMethodDescription(alsStrategy, joinPoint, throwable);
    }

    @Override
    protected String getContent(AlsStrategyBo alsStrategy, JoinPoint joinPoint, Throwable throwable) {
        return this.getThrowable(alsStrategy, joinPoint, throwable);
    }

}
