package ricciliao.common.component.als.resolver;

import com.fasterxml.jackson.databind.ObjectMapper;
import hk.health.medication.als.pojo.AlsRequestInfoDto;

public interface AlsRequestInfoResolver {

    AlsRequestInfoDto resolve(ObjectMapper objectMapper);

}
