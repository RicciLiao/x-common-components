package ricciliao.common.component.als.common;

public enum AlsContentModeEnum {

    PAYLOAD_MODE(1, "Store Request/response payload"),
    BASE_INFO_OR_TOKEN_MODE(2, "Store MOE header/CIMS2 token"),
    FULL_MODE(3, "Store Request/response payload && MOE header/CIMS2 token");

    private int mode;
    private String description;

    AlsContentModeEnum(int mode, String description) {
        this.mode = mode;
        this.description = description;
    }

    public int getMode() {
        return mode;
    }

    public String getDescription() {
        return description;
    }

}
