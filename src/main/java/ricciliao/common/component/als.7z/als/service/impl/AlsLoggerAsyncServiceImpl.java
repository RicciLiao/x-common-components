package ricciliao.common.component.als.service.impl;

import hk.health.medication.als.common.AlsLoggerUtil;
import hk.health.medication.als.config.AlsLoggerAsyncConfiguration;
import hk.health.medication.als.service.AlsLoggerAsyncService;
import hk.health.medication.exception.CimsConcurrentException;
import hk.health.medication.exception.CimsParamException;
import hk.health.medication.exception.CimsRecordException;
import hk.org.ha.service.app.audit.als.AlsMessage;
import org.springframework.dao.OptimisticLockingFailureException;

public class AlsLoggerAsyncServiceImpl implements AlsLoggerAsyncService {

    private final AlsLoggerAsyncConfiguration alsLoggerAsyncConfiguration;

    public AlsLoggerAsyncServiceImpl(AlsLoggerAsyncConfiguration alsLoggerAsyncConfiguration) {
        this.alsLoggerAsyncConfiguration = alsLoggerAsyncConfiguration;
    }

    @Override
    public void audit(AlsMessage audit) {
        alsLoggerAsyncConfiguration.getAuditExecutor().execute(() -> AlsLoggerUtil.audit(audit));
    }

    @Override
    public void info(AlsMessage info) {
        alsLoggerAsyncConfiguration.getAppExecutor().execute(() -> AlsLoggerUtil.info(info));
    }

    @Override
    public void warn(AlsMessage warn) {
        alsLoggerAsyncConfiguration.getAppExecutor().execute(() -> AlsLoggerUtil.warn(warn));
    }

    @Override
    public void critical(AlsMessage critical, Throwable throwable) {
        if (throwable instanceof CimsConcurrentException
                || throwable instanceof OptimisticLockingFailureException
                || throwable instanceof CimsRecordException
                || throwable instanceof CimsParamException) {
            alsLoggerAsyncConfiguration.getAppExecutor().execute(() -> AlsLoggerUtil.info(critical));
        } else {
            alsLoggerAsyncConfiguration.getAppExecutor().execute(() -> AlsLoggerUtil.critical(critical));
        }
    }

    @Override
    public void critical(AlsMessage critical) {
        alsLoggerAsyncConfiguration.getAppExecutor().execute(() -> AlsLoggerUtil.critical(critical));
    }

    @Override
    public void shutdownNow() {
        alsLoggerAsyncConfiguration.getAuditExecutor().getThreadPoolExecutor().shutdownNow();
        alsLoggerAsyncConfiguration.getAppExecutor().getThreadPoolExecutor().shutdownNow();
    }

}
