package ricciliao.common.component.als;

import com.fasterxml.jackson.core.Version;
import com.fasterxml.jackson.core.Versioned;
import com.fasterxml.jackson.core.util.VersionUtil;
import com.fasterxml.jackson.databind.introspect.Annotated;
import com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector;

public class AlsAnnotationIntrospector extends JacksonAnnotationIntrospector implements Versioned {

    private static final long serialVersionUID = -8221252115736933767L;

    @Override
    public Version version() {
        return VersionUtil.versionFor(getClass());
    }

    @Override
    public Object findSerializer(Annotated a) {

        if (a.hasAnnotation(AlsIgnore.class)) {

            return new AlsIgnoreSerializer();
        }

        return super.findSerializer(a);
    }
}
