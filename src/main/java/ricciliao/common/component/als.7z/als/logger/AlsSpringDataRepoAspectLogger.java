package ricciliao.common.component.als.logger;

import hk.health.medication.als.AlsBeanConfiguration;
import hk.health.medication.als.AlsLoggerFactory;
import hk.health.medication.als.AlsLoggerRegistry;
import hk.health.medication.als.common.AlsLoggerUtil;
import hk.health.medication.als.strategy.after.returning.AlsSpringDataStrategy;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.InvocationTargetException;

@Aspect
@AlsBeanConfiguration(name = AlsLoggerRegistry.BEAN_NAME_FOR_ALS_SPRING_DATA_REPO_ASPECT)
public class AlsSpringDataRepoAspectLogger extends AlsBaseAspect {

    private static final AlsGeneralLogger alsGeneralLogger = AlsLoggerFactory.getAlsGeneralLogger();
    private static final Logger logger = LoggerFactory.getLogger(AlsSpringDataRepoAspectLogger.class);

    private final Class<AlsSpringDataStrategy> alsSpringDataStrategyClass;

    public AlsSpringDataRepoAspectLogger(AlsLoggerRegistry alsLoggerRegistry, Class<AlsSpringDataStrategy> alsSpringDataStrategyClass) {
        super(alsLoggerRegistry);
        this.alsSpringDataStrategyClass = alsSpringDataStrategyClass;
    }


    @Pointcut("execution(public * hk.health.*.repository.*.*(..)) " +
            "|| execution(public * hk.health.*.assessment.repository.*.*(..))" +
            "|| execution(public * hk.health.*.consultation.repository.*.*(..))" +
            "|| execution(public * hk.health.sth.*.repository.*.*(..))" +
            "|| execution(public * hk.health.*.medication.repository.*.*(..))")
    public void repo() {
        // for *.repository package
    }

    @AfterReturning(pointcut = "repo()", returning = "returning")
    public void afterReturningForRepo(JoinPoint joinPoint, Object returning) {
        if (AlsLoggerUtil.isLoggingEnabled()) {
            try {
                AlsSpringDataStrategy alsSpringDataStrategy = alsSpringDataStrategyClass.getConstructor(AlsLoggerRegistry.class).newInstance(super.getAlsLoggerRegistry());
                super.getAlsLoggerAsyncService().info(alsSpringDataStrategy.process(joinPoint, returning));
            } catch (NoSuchMethodException | IllegalAccessException | InvocationTargetException | InstantiationException e) {
                alsGeneralLogger.critical(e.getMessage());
                if (logger.isErrorEnabled()) {
                    logger.error("", e);
                }
            }
        }
    }

    @AfterThrowing(pointcut = "repo()", throwing = "throwable")
    public void afterThrowingForRepo(JoinPoint joinPoint, Throwable throwable) {
        if (AlsLoggerUtil.isLoggingEnabled()) {
            super.getAlsLoggerAsyncService().critical(new hk.health.medication.als.strategy.after.throwing.impl.AlsDefaultThrowingImpl(super.getAlsLoggerRegistry()).process(joinPoint, throwable), throwable);
        }
    }

}
