package ricciliao.common.component.als.config;

import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.ThreadPoolExecutor;

public class AlsLoggerAsyncConfiguration {

    private final ThreadPoolTaskExecutor auditExecutor;
    private final ThreadPoolTaskExecutor appExecutor;

    public static final String EXECUTOR_NAME_FOR_AUDIT = "auditExecutor - ";
    public static final String EXECUTOR_NAME_FOR_APP = "appExecutor - ";

    public AlsLoggerAsyncConfiguration() {
        this.auditExecutor = auditExecutor();
        this.appExecutor = appExecutor();
    }

    public ThreadPoolTaskExecutor getAuditExecutor() {
        return auditExecutor;
    }

    public ThreadPoolTaskExecutor getAppExecutor() {
        return appExecutor;
    }

    private ThreadPoolTaskExecutor auditExecutor() {
        ThreadPoolTaskExecutor auditThreadPoolTaskExecutor = new ThreadPoolTaskExecutor();
        auditThreadPoolTaskExecutor.setCorePoolSize(20);
        auditThreadPoolTaskExecutor.setMaxPoolSize(50);
        auditThreadPoolTaskExecutor.setQueueCapacity(200);
        auditThreadPoolTaskExecutor.setKeepAliveSeconds(10);
        auditThreadPoolTaskExecutor.setThreadNamePrefix(EXECUTOR_NAME_FOR_AUDIT);
        auditThreadPoolTaskExecutor.setRejectedExecutionHandler(new ThreadPoolExecutor.CallerRunsPolicy());
        auditThreadPoolTaskExecutor.setWaitForTasksToCompleteOnShutdown(false);
        auditThreadPoolTaskExecutor.setAwaitTerminationSeconds(15);
        auditThreadPoolTaskExecutor.initialize();

        return auditThreadPoolTaskExecutor;
    }

    private ThreadPoolTaskExecutor appExecutor() {
        ThreadPoolTaskExecutor criticalThreadPoolTaskExecutor = new ThreadPoolTaskExecutor();
        criticalThreadPoolTaskExecutor.setCorePoolSize(10);
        criticalThreadPoolTaskExecutor.setMaxPoolSize(50);
        criticalThreadPoolTaskExecutor.setQueueCapacity(250);
        criticalThreadPoolTaskExecutor.setKeepAliveSeconds(10);
        criticalThreadPoolTaskExecutor.setThreadNamePrefix(EXECUTOR_NAME_FOR_APP);
        criticalThreadPoolTaskExecutor.setRejectedExecutionHandler(new ThreadPoolExecutor.CallerRunsPolicy());
        criticalThreadPoolTaskExecutor.setWaitForTasksToCompleteOnShutdown(false);
        criticalThreadPoolTaskExecutor.setAwaitTerminationSeconds(15);
        criticalThreadPoolTaskExecutor.initialize();

        return criticalThreadPoolTaskExecutor;
    }

}
