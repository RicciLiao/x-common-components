package ricciliao.common.component.als.logger;

import hk.health.medication.als.AlsLoggerRegistry;
import hk.health.medication.als.service.AlsLoggerAsyncService;

public class AlsBaseAspect {

    private final AlsLoggerRegistry alsLoggerRegistry;

    public AlsBaseAspect(AlsLoggerRegistry alsLoggerRegistry) {
        this.alsLoggerRegistry = alsLoggerRegistry;
    }

    public AlsLoggerRegistry getAlsLoggerRegistry() {
        return alsLoggerRegistry;
    }

    public AlsLoggerAsyncService getAlsLoggerAsyncService() {
        return alsLoggerRegistry.getAlsLoggerAsyncService();
    }

    public String getBaseProjectId() {
        return alsLoggerRegistry.getBaseProjectId();
    }

}
