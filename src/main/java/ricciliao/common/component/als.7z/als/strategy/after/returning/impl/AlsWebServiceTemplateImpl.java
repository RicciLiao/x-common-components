package ricciliao.common.component.als.strategy.after.returning.impl;

import hk.health.medication.als.AlsLoggerRegistry;
import hk.health.medication.als.common.AlsCommonHelper;
import hk.health.medication.als.common.AlsConstant;
import hk.health.medication.als.pojo.AlsStrategyBo;
import hk.health.medication.als.strategy.after.returning.AlsReturningStrategy;
import org.aspectj.lang.JoinPoint;

import javax.xml.bind.JAXBElement;

public class AlsWebServiceTemplateImpl extends AlsReturningStrategy<JAXBElement<Object>> {

    public AlsWebServiceTemplateImpl(AlsLoggerRegistry alsLoggerRegistry) {
        super(alsLoggerRegistry);
    }

    @Override
    protected String getMethodDescription(AlsStrategyBo alsStrategy, JoinPoint joinPoint) {

        return String.format(AlsConstant.ALS_BASE_DESCRIPTION_FORMAT_FOR_OUTBOUND_WS_RESPONSE,
                super.getAlsLoggerRegistry().getBaseProjectId(),
                ((JAXBElement) joinPoint.getArgs()[0]).getName().getLocalPart());
    }

    @Override
    protected String getMethodReturning(AlsStrategyBo alsStrategy, JAXBElement<Object> data) {

        return String.format(AlsConstant.ALS_BASE_RESULT_CONTENT_FORMAT,
                AlsCommonHelper.jaxbToXmlString(data));
    }

    @Override
    protected void destroy() {
        // do nothing
    }

}
