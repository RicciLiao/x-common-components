package ricciliao.common.component.als.pojo;

import hk.health.medication.als.common.AlsConstant;

import java.io.Serializable;

public class AlsTraceBo implements Serializable {
    private static final long serialVersionUID = -5732214910780604401L;

    private final long threadId = Thread.currentThread().getId();
    private boolean fromHttp = false;       // Identification of this trace is from http request or others
    private boolean b2b = false;    // Identification of this trace is backend -> backend or frontend -> backend
    private String uriForHttp;
    private String correlationId;
    private String transactionId;
    private String clientIpForHttp;
    private String workstationIdForHttp;
    private String locationCdForHttp;
    private String userIdForHttp;
    private String pmiNoForHttp;
    private String caseAndEncounterNoForHttp;
    private String patientIdentity;
    // for audit only -- start --
    private String frontendAction;
    private String functionCode;
    private String functionName;
    // for audit only -- end --

    private AlsTraceBo() {
        // newInstance()
    }

    public static AlsTraceBo newInstance() {
        return new AlsTraceBo();
    }

    public AlsTraceBo fromHttp() {
        this.fromHttp = true;
        return this;
    }

    public AlsTraceBo uriForHttp(String uriForHttp) {
        this.uriForHttp = uriForHttp;
        return this;
    }

    public AlsTraceBo correlationId(String correlationId) {
        this.correlationId = correlationId;
        return this;
    }

    public AlsTraceBo transactionId(String transactionId) {
        this.transactionId = transactionId;
        return this;
    }

    public AlsTraceBo clientIpForHttp(String clientIpForHttp) {
        this.clientIpForHttp = clientIpForHttp;
        return this;
    }

    public AlsTraceBo workstationIdForHttp(String workstationIdForHttp) {
        this.workstationIdForHttp = workstationIdForHttp;
        return this;
    }

    public AlsTraceBo locationCdForHttp(String locationCdForHttp) {
        this.locationCdForHttp = locationCdForHttp;
        return this;
    }

    public AlsTraceBo userIdForHttp(String userIdForHttp) {
        this.userIdForHttp = userIdForHttp;
        return this;
    }

    public AlsTraceBo b2b(boolean isb2b) {
        this.b2b = isb2b;
        return this;
    }

    public AlsTraceBo caseAndEncounterNoForHttp(String caseNoForHttp, String encounterNoForHttp) {
        this.caseAndEncounterNoForHttp = String.format(AlsConstant.ALS_CASE_NO_FORMAT, caseNoForHttp, encounterNoForHttp);
        return this;
    }

    public AlsTraceBo pmiNoForHttp(String pmiNoForHttp) {
        this.pmiNoForHttp = pmiNoForHttp;
        return this;
    }

    public AlsTraceBo patientIdentity(String patientIdentity) {
        this.patientIdentity = patientIdentity;
        return this;
    }

    public AlsTraceBo frontendAction(String frontendAction) {
        this.frontendAction = frontendAction;
        return this;
    }

    public AlsTraceBo functionCode(String functionCode) {
        this.functionCode = functionCode;
        return this;
    }

    public AlsTraceBo functionName(String functionName) {
        this.functionName = functionName;
        return this;
    }

    public long getThreadId() {
        return threadId;
    }

    public boolean isFromHttp() {
        return fromHttp;
    }

    public void setFromHttp(boolean fromHttp) {
        this.fromHttp = fromHttp;
    }

    public String getUriForHttp() {
        return uriForHttp;
    }

    public void setUriForHttp(String uriForHttp) {
        this.uriForHttp = uriForHttp;
    }

    public String getCorrelationId() {
        return correlationId;
    }

    public void setCorrelationId(String correlationId) {
        this.correlationId = correlationId;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getClientIpForHttp() {
        return clientIpForHttp;
    }

    public void setClientIpForHttp(String clientIpForHttp) {
        this.clientIpForHttp = clientIpForHttp;
    }

    public String getWorkstationIdForHttp() {
        return workstationIdForHttp;
    }

    public void setWorkstationIdForHttp(String workstationIdForHttp) {
        this.workstationIdForHttp = workstationIdForHttp;
    }

    public String getLocationCdForHttp() {
        return locationCdForHttp;
    }

    public void setLocationCdForHttp(String locationCdForHttp) {
        this.locationCdForHttp = locationCdForHttp;
    }

    public String getUserIdForHttp() {
        return userIdForHttp;
    }

    public void setUserIdForHttp(String userIdForHttp) {
        this.userIdForHttp = userIdForHttp;
    }

    public boolean isB2b() {
        return b2b;
    }

    public void setB2b(boolean b2b) {
        this.b2b = b2b;
    }

    public String getPmiNoForHttp() {
        return pmiNoForHttp;
    }

    public void setPmiNoForHttp(String pmiNoForHttp) {
        this.pmiNoForHttp = pmiNoForHttp;
    }

    public String getCaseAndEncounterNoForHttp() {
        return caseAndEncounterNoForHttp;
    }

    public void setCaseAndEncounterNoForHttp(String caseAndEncounterNoForHttp) {
        this.caseAndEncounterNoForHttp = caseAndEncounterNoForHttp;
    }

    public String getPatientIdentity() {
        return patientIdentity;
    }

    public void setPatientIdentity(String patientIdentity) {
        this.patientIdentity = patientIdentity;
    }

    public String getFrontendAction() {
        return frontendAction;
    }

    public void setFrontendAction(String frontendAction) {
        this.frontendAction = frontendAction;
    }

    public String getFunctionCode() {
        return functionCode;
    }

    public void setFunctionCode(String functionCode) {
        this.functionCode = functionCode;
    }

    public String getFunctionName() {
        return functionName;
    }

    public void setFunctionName(String functionName) {
        this.functionName = functionName;
    }
}
