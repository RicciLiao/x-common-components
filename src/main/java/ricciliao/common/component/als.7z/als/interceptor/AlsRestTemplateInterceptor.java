package ricciliao.common.component.als.interceptor;

import hk.health.medication.als.AlsLoggerRegistry;
import hk.health.medication.als.common.AlsConstant;
import hk.health.medication.als.pojo.AlsTraceBo;
import hk.health.medication.common.CommonHelper;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;

import java.io.IOException;

public class AlsRestTemplateInterceptor implements ClientHttpRequestInterceptor {

    private final AlsLoggerRegistry alsLoggerRegistry;

    public AlsRestTemplateInterceptor(AlsLoggerRegistry alsLoggerRegistry) {
        this.alsLoggerRegistry = alsLoggerRegistry;
    }

    @Override
    public ClientHttpResponse intercept(HttpRequest httpRequest, byte[] bytes, ClientHttpRequestExecution clientHttpRequestExecution) throws IOException {
        AlsTraceBo alsTrace = alsLoggerRegistry.getThreadIdAndAlsTraceMap().get(Thread.currentThread().getId());
        if (alsTrace != null && !CommonHelper.isBlank(alsTrace.getTransactionId())) {
            httpRequest.getHeaders().add(AlsConstant.HTTP_HEADER_TRANSACTION_ID, alsTrace.getTransactionId());
            httpRequest.getHeaders().add(AlsConstant.HTTP_HEADER_CORRELATION_ID, alsTrace.getCorrelationId());
        }

        return clientHttpRequestExecution.execute(httpRequest, bytes);
    }
}
