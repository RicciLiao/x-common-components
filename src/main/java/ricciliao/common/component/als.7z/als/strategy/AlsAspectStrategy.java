package ricciliao.common.component.als.strategy;

import hk.health.medication.als.AlsLoggerRegistry;
import hk.health.medication.als.common.AlsMapUtil;
import hk.health.medication.als.pojo.AlsStrategyBo;
import hk.health.medication.als.pojo.AlsTraceBo;
import hk.org.ha.service.app.audit.als.AlsMessage;
import org.aspectj.lang.JoinPoint;

public abstract class AlsAspectStrategy<T> {

    private final AlsLoggerRegistry alsLoggerRegistry;

    public AlsAspectStrategy(AlsLoggerRegistry alsLoggerRegistry) {
        this.alsLoggerRegistry = alsLoggerRegistry;
    }

    protected AlsLoggerRegistry getAlsLoggerRegistry() {
        return alsLoggerRegistry;
    }

    protected AlsStrategyBo initiate() {
        AlsMessage alsMessage = new AlsMessage();
        alsMessage.setEncryptFields("CONTENT");
        alsMessage.setFunctionId(alsLoggerRegistry.getBaseProjectId());
        AlsTraceBo alsTrace = AlsMapUtil.transferTrace(alsMessage, alsLoggerRegistry.getThreadIdAndAlsTraceMap());

        return new AlsStrategyBo(alsTrace, alsMessage);
    }

    public AlsMessage process(JoinPoint joinPoint, T data) {
        try {
            AlsStrategyBo alsStrategy = this.initiate();
            alsStrategy.getAlsMessage().setDescription(this.getDescription(alsStrategy, joinPoint, data));
            alsStrategy.getAlsMessage().setContent(this.getContent(alsStrategy, joinPoint, data));

            return alsStrategy.getAlsMessage();
        } finally {
            this.destroy();
        }
    }

    protected abstract String getDescription(AlsStrategyBo alsStrategy, JoinPoint joinPoint, T data);

    protected abstract String getContent(AlsStrategyBo alsStrategy, JoinPoint joinPoint, T data);

    protected abstract void destroy();

}
