package ricciliao.common.component.als.common;

import hk.org.ha.service.app.audit.als.model.Severity;

public class AlsConstant {

    private AlsConstant() {
        throw new IllegalStateException("Utility class");
    }

    public static final String CRITICAL = Severity.CRITICAL.toString();
    public static final String WARN = Severity.WARN.toString();
    public static final String AUDIT = "AUDIT";
    public static final String INFO = Severity.INFO.toString();

    public static final String HTTP_HEADER_CORRELATION_ID = "correlationId";
    public static final String HTTP_HEADER_SERVICE_CD = "serviceCode";
    public static final String HTTP_HEADER_WORKSTATION_ID = "wksName";
    public static final String HTTP_HEADER_CLINIC_CD = "clinicCode";
    public static final String HTTP_HEADER_CLIENT_IP = "ipAddr";
    public static final String HTTP_HEADER_TRANSACTION_ID = "transactionId";

    public static final String HTTP_HEADER_USER_ID = "userId";
    public static final String HTTP_HEADER_CASE_NO = "caseNo";
    public static final String HTTP_HEADER_ENCOUNTER_NO = "encounterNo";
    public static final String HTTP_HEADER_PMI_NO = "pmiNo";
    public static final String HTTP_HEADER_PATIENT_DOC_TYPE_CD = "docTypeCd";
    public static final String HTTP_HEADER_PATIENT_DOC_NO = "docNo";
    public static final String HTTP_HEADER_FRONTEND_ACTION = "frontend-action";
    public static final String HTTP_HEADER_FUNCTION_CODE = "function-code";
    public static final String HTTP_HEADER_FUNCTION_NAME = "function-name";

    public static final String HTTP_HEADER_AUTHORIZATION = "Authorization";
    public static final String HTTP_HEADER_BASE_INFO_AND_AUTHORIZATION_EMPTY = "#Both base info and CIMS2 token are empty#";


    public static final String ALS_CASE_NO_FORMAT = "FE: <%s>|<%s>";
    public static final String ALS_BASE_DESCRIPTION_FORMAT_FOR_COMPLETED = "[%s] %s(%s) completed";
    public static final String ALS_BASE_DESCRIPTION_FORMAT_FOR_EXCEPTION = "[%s] %s(%s) found Exception";
    public static final String ALS_BASE_DESCRIPTION_FORMAT_FOR_EXCEPTION_WITH_EXCEPTION_MESSAGE = "%s: %s";
    public static final String ALS_AUDIT_DESCRIPTION_FORMAT_FOR_INBOUND_RECEIVED = "[%s] Action: %s . Inbound API %s(%s) received %s";
    public static final String ALS_AUDIT_DESCRIPTION_FORMAT_FOR_INBOUND_COMPLETED = "[%s] Action: %s . Inbound API %s(%s) completed %s";
    public static final String ALS_BASE_DESCRIPTION_FORMAT_FOR_INBOUND_RECEIVED = "[%s] Inbound API %s(%s) received %s";
    public static final String ALS_BASE_DESCRIPTION_FORMAT_FOR_INBOUND_COMPLETED = "[%s] Inbound API %s(%s) completed %s";
    public static final String ALS_BASE_DESCRIPTION_FORMAT_FOR_INBOUND_WS_RECEIVED = "[%s] Inbound External Webservice API %s received .";
    public static final String ALS_BASE_DESCRIPTION_FORMAT_FOR_INBOUND_WS_COMPLETED = "[%s] Inbound External Webservice API %s completed .";

    public static final String ALS_BASE_DESCRIPTION_FORMAT_FOR_OUTBOUND_REQUEST = "[%s] Outbound API to %s request sent .";
    public static final String ALS_BASE_DESCRIPTION_FORMAT_FOR_OUTBOUND_RESPONSE = "[%s] Outbound API to %s response received .";
    public static final String ALS_BASE_DESCRIPTION_FORMAT_FOR_OUTBOUND_WS_REQUEST = "[%s] Outbound External Webservice to %s request sent .";
    public static final String ALS_BASE_DESCRIPTION_FORMAT_FOR_OUTBOUND_WS_RESPONSE = "[%s] Outbound External Webservice to %s response received .";
    public static final String ALS_BASE_THROWABLE_CONTENT_FORMAT = "Method throwable is [%s];";
    public static final String ALS_BASE_PARAMETERS_CONTENT_FORMAT = "Method parameters is [%s];";
    public static final String ALS_BASE_RESULT_CONTENT_FORMAT = "Method result is <%s>;";
    public static final String ALS_GNU_SED = ", ";
    public static final String ALS_BASE_DESCRIPTION_FORMAT_FOR_EXTRA_PMI = ", PMI: %s.";
    public static final String ALS_BASE_DESCRIPTION_FORMAT_FOR_EXTRA_POINT = ".";
    public static final String ALS_BASE_DESCRIPTION_FORMAT_FOR_BASE_INFO = "Base-info is <%s>;";
    public static final String ALS_BASE_DESCRIPTION_FORMAT_FOR_AUTHORIZATION = "CIMS2 token is <%s>;";


    public static final String ALS_PROJECT_CODE = "DHCIMS";

    public static final Integer ALS_ENCRYPT_INDICATOR = 0;
    public static final Integer ALS_NON_ENCRYPT_INDICATOR = 1;

    public static final String REGEX_START_WITH_TWO_ENGLISH_LETTERS = "[A-Za-z]{2}";
    public static final String ALS_HKID_LABEL = "HKID:";
    public static final String ALS_DOCUMENT_LABEL = "Document:";

    public static final String ALS_LOGGER_ERROR_MESSAGE = "Error: Failed to logging!";

    public static final String ALS_REST_CLIENT_EXCEPTION_MESSAGE_REGX = "^\\d{3}\\s{1}null$";

    public static final String ALS_STRUCTURED_QUERY_LANGUAGE_DESC = "SQL is <%s>;";
    public static final String ALS_STRUCTURED_QUERY_LANGUAGE_RESULT_COUNT = "Method result count is <%s>;";

}
