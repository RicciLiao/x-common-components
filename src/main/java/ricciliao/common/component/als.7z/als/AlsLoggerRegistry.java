package ricciliao.common.component.als;

import com.fasterxml.jackson.databind.ObjectMapper;
import hk.health.medication.als.config.AlsLoggerAsyncConfiguration;
import hk.health.medication.als.interceptor.AlsRestTemplateInterceptor;
import hk.health.medication.als.pojo.AlsTraceBo;
import hk.health.medication.als.resolver.AlsRequestInfoResolver;
import hk.health.medication.als.service.AlsLoggerAsyncService;
import hk.health.medication.als.service.impl.AlsLoggerAsyncServiceImpl;
import org.dozer.DozerBeanMapper;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;

import java.util.HashMap;
import java.util.Map;

public class AlsLoggerRegistry {

    public static final String BEAN_NAME_FOR_ALS_CONTROLLER_ASPECT = "alsControllerAspect";
    public static final String BEAN_NAME_FOR_ALS_JDBC_TEMPLATE_ASPECT = "alsJdbcTemplateAspect";
    public static final String BEAN_NAME_FOR_ALS_REST_SERVICE_ASPECT = "alsRestServiceAspect";
    public static final String BEAN_NAME_FOR_ALS_WEB_SERVICE_ASPECT = "alsWebServiceAspect";
    public static final String BEAN_NAME_FOR_ALS_WEB_SERVICE_ENDPOINT_ASPECT = "alsWebServiceEndpointAspect";
    public static final String BEAN_NAME_FOR_ALS_SPRING_DATA_REPO_ASPECT = "AlsSpringDataRepoAspect";
    public static final String BEAN_NAME_FOR_ALS_LOGGER_FACTORY = "alsLoggerFactory";

    private final String baseProjectId;
    private final AlsLoggerAsyncConfiguration alsLoggerAsyncConfiguration;
    private final AlsLoggerAsyncService alsLoggerAsyncService;
    private final Map<Long, AlsTraceBo> threadIdAndAlsTraceMap;
    private final ObjectMapper objectMapper;
    private final AlsRestTemplateInterceptor alsRestTemplateInterceptor;
    private final AlsRequestInfoResolver alsRequestResolver;
    private final DozerBeanMapper dozerBeanMapper;
    private final MappingJackson2HttpMessageConverter mappingJackson2HttpMessageConverter;

    public AlsLoggerRegistry(String baseProjectId,
                             ObjectMapper objectMapper,
                             AlsRequestInfoResolver alsRequestResolver) {
        this.baseProjectId = baseProjectId;
        this.alsLoggerAsyncConfiguration = new AlsLoggerAsyncConfiguration();
        this.alsLoggerAsyncService = new AlsLoggerAsyncServiceImpl(this.alsLoggerAsyncConfiguration);
        this.threadIdAndAlsTraceMap = new HashMap<>();
        this.objectMapper = objectMapper;
        this.alsRestTemplateInterceptor = new AlsRestTemplateInterceptor(this);
        this.alsRequestResolver = alsRequestResolver;
        this.dozerBeanMapper = new DozerBeanMapper();
        this.mappingJackson2HttpMessageConverter = new MappingJackson2HttpMessageConverter(objectMapper);
    }

    public String getBaseProjectId() {
        return baseProjectId;
    }

    public AlsLoggerAsyncConfiguration getAlsLoggerAsyncConfiguration() {
        return alsLoggerAsyncConfiguration;
    }

    public AlsLoggerAsyncService getAlsLoggerAsyncService() {
        return alsLoggerAsyncService;
    }

    public Map<Long, AlsTraceBo> getThreadIdAndAlsTraceMap() {
        return threadIdAndAlsTraceMap;
    }

    public ObjectMapper getObjectMapper() {
        return objectMapper;
    }

    public AlsRestTemplateInterceptor getAlsRestTemplateInterceptor() {
        return alsRestTemplateInterceptor;
    }

    public AlsRequestInfoResolver getAlsRequestResolver() {
        return alsRequestResolver;
    }

    public DozerBeanMapper getDozerBeanMapper() {
        return dozerBeanMapper;
    }

    public MappingJackson2HttpMessageConverter getMappingJackson2HttpMessageConverter() {
        return mappingJackson2HttpMessageConverter;
    }
}
