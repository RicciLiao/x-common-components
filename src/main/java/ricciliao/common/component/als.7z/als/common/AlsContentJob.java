package ricciliao.common.component.als.common;

@FunctionalInterface
public interface AlsContentJob<T, Z> {
    T executor(Z z);
}
