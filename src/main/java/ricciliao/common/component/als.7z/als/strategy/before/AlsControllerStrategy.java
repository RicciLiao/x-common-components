package ricciliao.common.component.als.strategy.before;

import hk.health.medication.als.AlsLoggerRegistry;
import hk.health.medication.als.common.AlsCommonHelper;
import hk.health.medication.als.common.AlsConstant;
import hk.health.medication.als.common.AlsContent;
import hk.health.medication.als.common.AlsContentModeEnum;
import hk.health.medication.als.common.AlsEncryptionModeEnum;
import hk.health.medication.als.common.AlsLoggerUtil;
import hk.health.medication.als.pojo.AlsContentJobBo;
import hk.health.medication.als.pojo.AlsStrategyBo;
import hk.health.medication.als.strategy.AlsAspectStrategy;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.validation.BindingResult;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public abstract class AlsControllerStrategy<T> extends AlsBeforeStrategy<T> {

    public AlsControllerStrategy(AlsLoggerRegistry alsLoggerRegistry) {
        super(alsLoggerRegistry);
    }

    @Override
    protected String getContent(AlsStrategyBo alsStrategy, JoinPoint joinPoint, T data) {
        AlsContent alsContent = ((MethodSignature) joinPoint.getSignature()).getMethod().getAnnotation(AlsContent.class);
        AlsEncryptionModeEnum alsEncryptionModeEnum = alsContent != null ? alsContent.isRequestEncrypted() : AlsEncryptionModeEnum.DEFAULT;
        boolean isEncrypted = AlsEncryptionModeEnum.DEFAULT.equals(alsEncryptionModeEnum) ? AlsLoggerUtil.isRequestEncrypted() : AlsEncryptionModeEnum.CIPHERED.equals(alsEncryptionModeEnum);
        AlsContentModeEnum alsContentModeEnum = alsContent != null ? alsContent.requestMode() : AlsContentModeEnum.BASE_INFO_OR_TOKEN_MODE;

        return AlsCommonHelper.alsContentJob(
                new AlsContentJobBo<>(alsStrategy, joinPoint, data, this,
                        (AlsAspectStrategy<T> alsAspectStrategy) -> this.getMethodArgs(alsStrategy, joinPoint),
                        super.getAlsLoggerRegistry().getBaseProjectId()
                ), isEncrypted, alsContentModeEnum
        );
    }

    @Override
    protected String getMethodArgs(AlsStrategyBo alsStrategy, JoinPoint joinPoint) {

        StringBuilder content = new StringBuilder();
        if (joinPoint.getArgs().length > 0) {
            for (Object arg : joinPoint.getArgs()) {
                if (arg instanceof HttpServletRequest
                        || arg instanceof HttpServletResponse) {
                    content.append(arg.getClass().getSimpleName());
                } else if (arg instanceof BindingResult) {
                    content.append(((BindingResult) arg).getFieldErrorCount())
                            .append(" ")
                            .append("errors in ")
                            .append(((BindingResult) arg).getTarget().getClass().getSimpleName())
                            .append("}");
                } else {
                    content.append(AlsCommonHelper.objectToJsonString(arg, super.getAlsLoggerRegistry().getObjectMapper()));
                }
                content.append(AlsConstant.ALS_GNU_SED);
            }

            return String.format(AlsConstant.ALS_BASE_PARAMETERS_CONTENT_FORMAT,
                    content.substring(0, content.length() - AlsConstant.ALS_GNU_SED.length()));
        }

        return String.format(AlsConstant.ALS_BASE_PARAMETERS_CONTENT_FORMAT, content.toString());
    }

}
