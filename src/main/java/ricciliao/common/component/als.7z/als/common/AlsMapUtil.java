package ricciliao.common.component.als.common;

import hk.health.medication.als.pojo.AlsTraceBo;
import hk.org.ha.service.app.audit.als.AlsLogger;
import hk.org.ha.service.app.audit.als.AlsMessage;

import java.util.Map;

public class AlsMapUtil {

    private AlsMapUtil() {
        throw new IllegalStateException("Utility class");
    }

    public static AlsTraceBo transferTrace(AlsMessage target, Map<Long, AlsTraceBo> sources) {
        AlsTraceBo source = AlsCommonHelper.getAlsTraceByCurrentThread(sources);
        if (source == null) {
            source = AlsTraceBo.newInstance()
                    .correlationId(AlsLogger.getUniqueId())
                    .transactionId(AlsLogger.getUniqueId());
            sources.put(source.getThreadId(), source);
        } else {
            if (source.isFromHttp()) {  // Frontend -> Backend
                target.setOperationId(source.getUriForHttp());
                target.setClientIp(source.getClientIpForHttp());
                target.setWorkstationId(source.getWorkstationIdForHttp());
                target.setLocationCd(source.getLocationCdForHttp());
                target.setUserId(source.getUserIdForHttp());
                target.setCaseNo(source.getCaseAndEncounterNoForHttp());
                target.setPatientIdentity(source.getPatientIdentity());
                target.setFunctionId(source.getFunctionCode());
            }
        }

        target.setCorrelationId(source.getCorrelationId());
        target.setTransactionId(source.getTransactionId());

        return source;
    }
}
