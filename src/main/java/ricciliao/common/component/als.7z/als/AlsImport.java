package ricciliao.common.component.als;

import com.fasterxml.jackson.databind.JsonSerializer;
import hk.health.medication.als.logger.AlsBaseAspect;
import hk.health.medication.als.logger.AlsControllerAspectLogger;
import hk.health.medication.als.logger.AlsJdbcTemplateAspectLogger;
import hk.health.medication.als.logger.AlsRestServiceAspectLogger;
import hk.health.medication.als.logger.AlsSpringDataRepoAspectLogger;
import hk.health.medication.als.logger.AlsWebEndpointLogger;
import hk.health.medication.als.logger.AlsWebServiceTemplateLogger;
import hk.health.medication.als.resolver.AlsRequestInfoResolver;
import hk.health.medication.als.resolver.impl.AlsRequestInfoDefaultResolver;
import hk.health.medication.als.strategy.after.returning.AlsSpringDataStrategy;
import hk.health.medication.als.strategy.after.returning.impl.AlsJpaImpl;
import org.springframework.context.annotation.Import;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Documented
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Import(AlsImporter.class)
public @interface AlsImport {

    String baseProjectId();

    Class<? extends AlsBaseAspect>[] aspectLoggers()
            default
            {
                    AlsControllerAspectLogger.class,
                    AlsJdbcTemplateAspectLogger.class,
                    AlsRestServiceAspectLogger.class,
                    AlsWebServiceTemplateLogger.class,
                    AlsWebEndpointLogger.class,
                    AlsSpringDataRepoAspectLogger.class
            };

    Class<? extends AlsRequestInfoResolver> alsRequestInfoResolver()
            default AlsRequestInfoDefaultResolver.class;

    Class<? extends JsonSerializer>[] jsonSerializers() default {};

    Class<? extends AlsSpringDataStrategy> alsSpringDataStrategy() default AlsJpaImpl.class;

}
