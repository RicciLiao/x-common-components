package ricciliao.common.component.als.logger;

import hk.health.medication.als.AlsBeanConfiguration;
import hk.health.medication.als.AlsLoggerRegistry;
import hk.health.medication.als.common.AlsCommonHelper;
import hk.health.medication.als.pojo.AlsTraceBo;
import hk.health.medication.als.strategy.after.throwing.impl.AlsDefaultThrowingImpl;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
@AlsBeanConfiguration(name = AlsLoggerRegistry.BEAN_NAME_FOR_ALS_CONTROLLER_ASPECT)
public class AlsControllerAspectLogger extends AlsBaseAspect {

    public AlsControllerAspectLogger(AlsLoggerRegistry alsLoggerRegistry) {
        super(alsLoggerRegistry);
    }

    @Pointcut("!@annotation(hk.health.medication.als.common.NoAlsLog) && !@target(hk.health.medication.als.common.NoAlsLog)")
    public void pointCutNoAlsLog() {
        // @Pointcut
    }

    @Pointcut("execution(public * hk.health.*.controller.*.*(..)) " +
            "|| execution(public * hk.health.*.assessment.controller.*.*(..)) " +
            "|| execution(public * hk.health.*.consultation.controller.*.*(..)) " +
            "|| execution(public * hk.health.sth.*.controller.*.*(..)) " +
            "|| execution(public * hk.health.*.medication.controller.*.*(..)) " +
            "|| execution(public * hk.health.medication.als.controller.AlsController.*(..)) ")
    public void pointCut() {
        // @Pointcut
    }

    @Before(value = "pointCut() && pointCutNoAlsLog()")
    public void before(JoinPoint joinPoint) {
        AlsTraceBo alsTraceBo = AlsCommonHelper.setAlsTraceByCurrentThread(super.getAlsLoggerRegistry());
        if (alsTraceBo.isB2b()) {
            this.getAlsLoggerAsyncService().info(new hk.health.medication.als.strategy.before.impl.AlsControllerImpl(this.getAlsLoggerRegistry()).process(joinPoint, null));
        } else {
            this.getAlsLoggerAsyncService().audit(new hk.health.medication.als.strategy.before.impl.AlsControllerAuditImpl(this.getAlsLoggerRegistry()).process(joinPoint, null));
        }
    }

    @AfterReturning(pointcut = "pointCut() && pointCutNoAlsLog()", returning = "returning")
    public void afterReturning(JoinPoint joinPoint, Object returning) {
        AlsTraceBo alsTraceBo = AlsCommonHelper.getAlsTraceByCurrentThread(super.getAlsLoggerRegistry().getThreadIdAndAlsTraceMap());
        if (alsTraceBo.isB2b()) {
            this.getAlsLoggerAsyncService().info(new hk.health.medication.als.strategy.after.returning.impl.AlsControllerImpl(this.getAlsLoggerRegistry()).process(joinPoint, returning));
        } else {
            this.getAlsLoggerAsyncService().audit(new hk.health.medication.als.strategy.after.returning.impl.AlsControllerAuditImpl(this.getAlsLoggerRegistry()).process(joinPoint, returning));
        }
    }

    @AfterThrowing(pointcut = "pointCut()", throwing = "throwable")
    public void afterThrowing(JoinPoint joinPoint, Throwable throwable) {
        this.getAlsLoggerAsyncService().critical(new AlsDefaultThrowingImpl(this.getAlsLoggerRegistry()).process(joinPoint, throwable), throwable);
    }

}
