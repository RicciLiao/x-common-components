package ricciliao.common.component.als.strategy.before.impl;

import hk.health.medication.als.AlsLoggerRegistry;
import hk.health.medication.als.common.AlsConstant;
import hk.health.medication.als.pojo.AlsStrategyBo;
import hk.health.medication.als.strategy.before.AlsControllerStrategy;
import org.aspectj.lang.JoinPoint;

public class AlsControllerImpl extends AlsControllerStrategy<Object> {

    public AlsControllerImpl(AlsLoggerRegistry alsLoggerRegistry) {
        super(alsLoggerRegistry);
    }

    @Override
    protected String getMethodDescription(AlsStrategyBo alsStrategy, JoinPoint joinPoint) {
        String[] signatureArr = joinPoint.getSignature().toString().split("\\.");

        return String.format(AlsConstant.ALS_BASE_DESCRIPTION_FORMAT_FOR_INBOUND_RECEIVED,
                super.getAlsLoggerRegistry().getBaseProjectId(),
                signatureArr[signatureArr.length - 2],
                signatureArr[signatureArr.length - 1],
                "");
    }

    @Override
    protected void destroy() {
        // do nothing
    }

}
