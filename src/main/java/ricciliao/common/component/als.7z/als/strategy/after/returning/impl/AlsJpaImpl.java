package ricciliao.common.component.als.strategy.after.returning.impl;

import hk.health.medication.als.AlsLoggerRegistry;
import hk.health.medication.als.common.AlsConstant;
import hk.health.medication.als.pojo.AlsStrategyBo;
import hk.health.medication.als.strategy.after.returning.AlsSpringDataStrategy;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.data.jpa.repository.Query;

import java.lang.reflect.Method;

public class AlsJpaImpl extends AlsSpringDataStrategy {

    public AlsJpaImpl(AlsLoggerRegistry alsLoggerRegistry) {
        super(alsLoggerRegistry);
    }

    @Override
    protected String getQuery(JoinPoint joinPoint) {
        Method method = ((MethodSignature) joinPoint.getSignature()).getMethod();
        Query query = method.getAnnotation(Query.class);
        if (query != null) {

            return String.format(AlsConstant.ALS_STRUCTURED_QUERY_LANGUAGE_DESC, query.value());
        } else {

            return String.format(AlsConstant.ALS_STRUCTURED_QUERY_LANGUAGE_DESC, joinPoint.getSignature().toString());
        }
    }

    @Override
    protected String getMethodDescription(AlsStrategyBo alsStrategy, JoinPoint joinPoint) {

        if (joinPoint.getSignature().toShortString().contains("BaseRepositoryImpl.findAll(..)")) {

            return String.format(AlsConstant.ALS_BASE_DESCRIPTION_FORMAT_FOR_COMPLETED,
                    super.getAlsLoggerRegistry().getBaseProjectId(),
                    "BaseRepositoryImpl",
                    "findAll(" + ((Class) joinPoint.getArgs()[0]).getSimpleName() + ")",
                    "");
        }

        return super.getMethodDescription(alsStrategy, joinPoint);
    }

    @Override
    protected void destroy() {
        // do nothing
    }

}
