package ricciliao.common.component.als.common;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import hk.health.medication.als.AlsLoggerRegistry;
import hk.health.medication.als.pojo.AlsContentJobBo;
import hk.health.medication.als.pojo.AlsRequestInfoDto;
import hk.health.medication.als.pojo.AlsTraceBo;
import hk.health.medication.als.resolver.AlsRequestInfoResolver;
import hk.health.medication.common.CommonHelper;
import hk.health.medication.context.HttpContextUtil;
import hk.health.medication.exception.CimsExceptionUtil;
import hk.org.ha.service.app.audit.als.AlsLogger;
import org.apache.commons.lang3.StringUtils;

import javax.servlet.http.HttpServletRequest;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import java.io.StringWriter;
import java.util.Map;

public class AlsCommonHelper {

    private AlsCommonHelper() {
        throw new IllegalStateException("Utility class");
    }

    public static String convertPatientIdentity(String docTypeCd, String docNum) {

        if (docTypeCd == null || docNum == null) {
            return "";
        }
        StringBuilder sbr;
        if (docTypeCd.equalsIgnoreCase("ID")) {
            sbr = new StringBuilder(AlsConstant.ALS_HKID_LABEL);
            //Add leading space in HKID
            if (docNum.length() >= 2
                    && docNum.substring(0, 2).matches(AlsConstant.REGEX_START_WITH_TWO_ENGLISH_LETTERS)) {
                return sbr.append(docNum).toString();
            }

            return sbr.append(" ").append(docNum).toString();
        } else {
            sbr = new StringBuilder(AlsConstant.ALS_DOCUMENT_LABEL);

            return sbr.append(docNum).toString();
        }
    }

    public static AlsTraceBo setAlsTraceByCurrentThread(AlsLoggerRegistry alsLoggerRegistry) {

        String correlationId = AlsLogger.getUniqueId();
        String transactionId = AlsLogger.getUniqueId();
        AlsTraceBo alsTrace = AlsTraceBo.newInstance();
        HttpServletRequest httpServletRequest = HttpContextUtil.getHttpServletRequest();

        if (httpServletRequest != null) {
            String userId = httpServletRequest.getHeader(AlsConstant.HTTP_HEADER_USER_ID);
            correlationId =
                    CommonHelper.blankStrSelector(httpServletRequest.getHeader(AlsConstant.HTTP_HEADER_CORRELATION_ID), correlationId);
            transactionId =
                    CommonHelper.blankStrSelector(httpServletRequest.getHeader(AlsConstant.HTTP_HEADER_TRANSACTION_ID), transactionId);
            String clientIp =
                    CommonHelper.blankStrSelector(httpServletRequest.getHeader(AlsConstant.HTTP_HEADER_CLIENT_IP), "");
            String workstationId =
                    CommonHelper.blankStrSelector(httpServletRequest.getHeader(AlsConstant.HTTP_HEADER_WORKSTATION_ID), "");
            String frontendAction =
                    CommonHelper.blankStrSelector(httpServletRequest.getHeader(AlsConstant.HTTP_HEADER_FRONTEND_ACTION), "");
            String functionCode =
                    CommonHelper.blankStrSelector(httpServletRequest.getHeader(AlsConstant.HTTP_HEADER_FUNCTION_CODE), "");
            String functionName =
                    CommonHelper.blankStrSelector(httpServletRequest.getHeader(AlsConstant.HTTP_HEADER_FUNCTION_NAME), "");

            AlsRequestInfoResolver alsRequestResolver = alsLoggerRegistry.getAlsRequestResolver();
            AlsRequestInfoDto alsRequestDto = alsRequestResolver.resolve(alsLoggerRegistry.getObjectMapper());
            String caseNo = CommonHelper.blankStrSelector(alsRequestDto.getCaseNo(), "");
            String encounterNo = CommonHelper.blankStrSelector(alsRequestDto.getEncounterNo(), "");
            String pmiNo = CommonHelper.blankStrSelector(alsRequestDto.getPmiNo(), "");
            String patientIdentity = "";
            if (!CommonHelper.isBlank(alsRequestDto.getDocTypeCd())
                    && !CommonHelper.isBlank(alsRequestDto.getDocNo())) {
                patientIdentity = convertPatientIdentity(alsRequestDto.getDocTypeCd(), alsRequestDto.getDocNo());
            }
            alsTrace.fromHttp()
                    .uriForHttp(httpServletRequest.getRequestURI())
                    .clientIpForHttp(clientIp)
                    .workstationIdForHttp(workstationId)
                    .locationCdForHttp(getLocationCd(httpServletRequest))
                    .userIdForHttp(userId)
                    .caseAndEncounterNoForHttp(caseNo, encounterNo)
                    .pmiNoForHttp(pmiNo)
                    .patientIdentity(patientIdentity)
                    .b2b(CommonHelper.isBlank(userId))
                    .frontendAction(frontendAction)
                    .functionCode(functionCode)
                    .functionName(functionName);
        }

        alsTrace.correlationId(correlationId)
                .transactionId(transactionId);
        alsLoggerRegistry.getThreadIdAndAlsTraceMap().put(alsTrace.getThreadId(), alsTrace);

        return alsTrace;
    }

    public static String getLocationCd(HttpServletRequest httpServletRequest) {
        StringBuilder locationCd = new StringBuilder();
        if (!CommonHelper.isBlank(httpServletRequest.getHeader(AlsConstant.HTTP_HEADER_SERVICE_CD))) {
            locationCd.append(httpServletRequest.getHeader(AlsConstant.HTTP_HEADER_SERVICE_CD));
            if (!CommonHelper.isBlank(httpServletRequest.getHeader(AlsConstant.HTTP_HEADER_CLINIC_CD))) {
                locationCd.append("|").append(httpServletRequest.getHeader(AlsConstant.HTTP_HEADER_CLINIC_CD));
            }
        } else {
            if (!CommonHelper.isBlank(httpServletRequest.getHeader(AlsConstant.HTTP_HEADER_CLINIC_CD))) {
                locationCd.append(httpServletRequest.getHeader(AlsConstant.HTTP_HEADER_CLINIC_CD));
            }
        }

        return locationCd.toString();
    }

    public static AlsTraceBo getAlsTraceByCurrentThread(Map<Long, AlsTraceBo> threadIdAndAlsTraceMap) {

        return threadIdAndAlsTraceMap.get(Thread.currentThread().getId());
    }

    public static String getThrowable(Throwable throwable) {
        StringBuilder content = new StringBuilder();

        return String.format(AlsConstant.ALS_BASE_THROWABLE_CONTENT_FORMAT,
                content.append(CimsExceptionUtil.stackTraceToString(throwable)));
    }

    public static void removeAlsTraceByCurrentThread(AlsLoggerRegistry alsLoggerRegistry) {
        alsLoggerRegistry.getThreadIdAndAlsTraceMap().remove(Thread.currentThread().getId());
    }

    public static <T> String jaxbToXmlString(JAXBElement<T> jaxbElement) {
        StringWriter sw = new StringWriter();
        try {
            JAXBContext context = JAXBContext.newInstance(jaxbElement.getValue().getClass());
            Marshaller marshaller = context.createMarshaller();
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
            marshaller.setProperty(Marshaller.JAXB_FRAGMENT, Boolean.TRUE);
            marshaller.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
            marshaller.marshal(jaxbElement, sw);

            return sw.toString();
        } catch (JAXBException e) {
            return jaxbElement.getValue().getClass().getSimpleName();
        }
    }

    public static String objectToJsonString(Object data, ObjectMapper objectMapper) {
        try {

            return objectMapper.writeValueAsString(data);
        } catch (JsonProcessingException e) {

            return data.getClass().getSimpleName();
        }
    }

    public static String baseInfoOrToken(String projectId) {
        String jwt = HttpContextUtil.getHttpServletRequest().getHeader(AlsConstant.HTTP_HEADER_AUTHORIZATION);
        String baseInfo = HttpContextUtil.getHttpServletRequest().getHeader(projectId);
        if (StringUtils.isNotBlank(baseInfo)) {

            return String.format(AlsConstant.ALS_BASE_DESCRIPTION_FORMAT_FOR_BASE_INFO, baseInfo);
        }
        if (StringUtils.isNotBlank(jwt)) {

            return String.format(AlsConstant.ALS_BASE_DESCRIPTION_FORMAT_FOR_AUTHORIZATION, jwt);
        }

        return AlsConstant.HTTP_HEADER_BASE_INFO_AND_AUTHORIZATION_EMPTY;
    }

    public static <T> String alsContentJob(AlsContentJobBo<T> job,
                                           boolean isEncrypted,
                                           AlsContentModeEnum alsContentModeEnum) {
        job.getAlsStrategy().getAlsMessage().setEncryptFields(isEncrypted ? "CONTENT" : "");
        if (AlsLoggerUtil.isContentFullMode() || AlsContentModeEnum.FULL_MODE.getMode() == alsContentModeEnum.getMode()) {
            StringBuilder content = new StringBuilder(job.getAspectStrategyJob().executor(job.getAlsAspectStrategy()));
            content.append(AlsCommonHelper.baseInfoOrToken(job.getBaseProjectId()));

            return content.toString();
        }

        if (AlsContentModeEnum.BASE_INFO_OR_TOKEN_MODE.getMode() == alsContentModeEnum.getMode()) {

            return AlsCommonHelper.baseInfoOrToken(job.getBaseProjectId());
        }

        return job.getAspectStrategyJob().executor(job.getAlsAspectStrategy());
    }


}
