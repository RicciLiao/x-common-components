package ricciliao.common.component.als.logger;

import hk.health.medication.als.AlsBeanConfiguration;
import hk.health.medication.als.AlsLoggerRegistry;
import hk.health.medication.als.strategy.before.impl.AlsWebServiceTemplateImpl;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

import javax.xml.bind.JAXBElement;

@Aspect
@AlsBeanConfiguration(name = AlsLoggerRegistry.BEAN_NAME_FOR_ALS_WEB_SERVICE_ASPECT)
public class AlsWebServiceTemplateLogger extends AlsBaseAspect {

    public AlsWebServiceTemplateLogger(AlsLoggerRegistry alsLoggerRegistry) {
        super(alsLoggerRegistry);
    }

    @Pointcut("execution(public Object org.springframework.ws.client.core.WebServiceTemplate.marshalSendAndReceive(Object)))")
    public void pointCut() {
        // @Pointcut
    }

    @Before(value = "pointCut()")
    public void before(JoinPoint joinPoint) {
        super.getAlsLoggerAsyncService().info(new AlsWebServiceTemplateImpl(super.getAlsLoggerRegistry()).process(joinPoint, null));
    }

    @AfterReturning(pointcut = "pointCut()", returning = "returning")
    public void afterReturning(JoinPoint joinPoint, Object returning) {
        super.getAlsLoggerAsyncService().info(new hk.health.medication.als.strategy.after.returning.impl.AlsWebServiceTemplateImpl(super.getAlsLoggerRegistry()).process(joinPoint, (JAXBElement) returning));
    }

    @AfterThrowing(pointcut = "pointCut()", throwing = "throwable")
    public void afterThrowing(JoinPoint joinPoint, Throwable throwable) {
        super.getAlsLoggerAsyncService().warn(new hk.health.medication.als.strategy.after.throwing.impl.AlsDefaultThrowingImpl(super.getAlsLoggerRegistry()).process(joinPoint, throwable));
    }

}
