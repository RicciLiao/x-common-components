package ricciliao.common.component.als.service;

import hk.org.ha.service.app.audit.als.AlsMessage;

public interface AlsLoggerAsyncService {

    void audit(AlsMessage alsMessage);

    void info(AlsMessage alsMessage);

    void warn(AlsMessage alsMessage);

    void critical(AlsMessage alsMessage, Throwable throwable);

    void critical(AlsMessage alsMessage);

    void shutdownNow();

}
