package ricciliao.common.component.als.logger;

import hk.health.medication.als.AlsLoggerRegistry;
import hk.health.medication.als.common.AlsConstant;
import hk.health.medication.als.common.AlsMapUtil;
import hk.health.medication.exception.CimsExceptionUtil;
import hk.org.ha.service.app.audit.als.AlsMessage;

public class AlsGeneralLogger {

    private final AlsLoggerRegistry alsLoggerRegistry;

    public AlsGeneralLogger(AlsLoggerRegistry alsLoggerRegistry) {
        this.alsLoggerRegistry = alsLoggerRegistry;
    }

    private AlsMessage newInstance(StackTraceElement stackTraceElement, String content) {
        AlsMessage alsMessage = new AlsMessage();
        alsMessage.setEncryptFields("CONTENT");
        AlsMapUtil.transferTrace(alsMessage, alsLoggerRegistry.getThreadIdAndAlsTraceMap());
        alsMessage.setDescription(
                String.format(AlsConstant.ALS_BASE_DESCRIPTION_FORMAT_FOR_EXCEPTION,
                        alsLoggerRegistry.getBaseProjectId(), stackTraceElement.getClassName(), stackTraceElement.getMethodName())
        );
        alsMessage.setContent(content);

        return alsMessage;
    }

    private AlsMessage newInstance(String description, String content) {
        AlsMessage alsMessage = new AlsMessage();
        alsMessage.setEncryptFields("CONTENT");
        AlsMapUtil.transferTrace(alsMessage, alsLoggerRegistry.getThreadIdAndAlsTraceMap());
        alsMessage.setDescription(description);
        alsMessage.setContent(content);

        return alsMessage;
    }

    public void warn(String content) {
        alsLoggerRegistry.getAlsLoggerAsyncService().warn(
                newInstance(Thread.currentThread().getStackTrace()[2], content)
        );
    }

    public void critical(String content) {
        alsLoggerRegistry.getAlsLoggerAsyncService().critical(
                newInstance(Thread.currentThread().getStackTrace()[2], content)
        );
    }

    public void info(String description, String content) {
        alsLoggerRegistry.getAlsLoggerAsyncService().info(
                newInstance("[" + alsLoggerRegistry.getBaseProjectId() + "] " + description, content)
        );
    }

    public void warn(String description, Throwable throwable) {
        alsLoggerRegistry.getAlsLoggerAsyncService().warn(
                newInstance(
                        Thread.currentThread().getStackTrace()[2],
                        buildThrowableContent(description, CimsExceptionUtil.stackTraceToString(throwable))
                )
        );
    }

    public void critical(String description, Throwable throwable) {
        alsLoggerRegistry.getAlsLoggerAsyncService().critical(
                newInstance(Thread.currentThread().getStackTrace()[2],
                        buildThrowableContent(description, CimsExceptionUtil.stackTraceToString(throwable))
                )
        );
    }

    private String buildThrowableContent(String description, String stack) {
        StringBuilder result = new StringBuilder();
        result.append(description)
                .append(System.lineSeparator())
                .append(stack);

        return result.toString();
    }

}
