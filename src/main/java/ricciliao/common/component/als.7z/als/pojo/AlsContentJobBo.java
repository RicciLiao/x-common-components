package ricciliao.common.component.als.pojo;

import hk.health.medication.als.common.AlsContentJob;
import hk.health.medication.als.strategy.AlsAspectStrategy;
import org.aspectj.lang.JoinPoint;

public class AlsContentJobBo<T> {

    public AlsContentJobBo(AlsStrategyBo alsStrategy,
                           JoinPoint joinPoint,
                           T data,
                           AlsAspectStrategy<T> alsAspectStrategy,
                           AlsContentJob<String, AlsAspectStrategy<T>> aspectStrategyJob,
                           String baseProjectId) {
        this.alsStrategy = alsStrategy;
        this.joinPoint = joinPoint;
        this.data = data;
        this.alsAspectStrategy = alsAspectStrategy;
        this.aspectStrategyJob = aspectStrategyJob;
        this.baseProjectId = baseProjectId;
    }

    private AlsStrategyBo alsStrategy;
    private JoinPoint joinPoint;
    private T data;
    private AlsAspectStrategy<T> alsAspectStrategy;
    private AlsContentJob<String, AlsAspectStrategy<T>> aspectStrategyJob;
    private String baseProjectId;

    public AlsStrategyBo getAlsStrategy() {
        return alsStrategy;
    }

    public void setAlsStrategy(AlsStrategyBo alsStrategy) {
        this.alsStrategy = alsStrategy;
    }

    public JoinPoint getJoinPoint() {
        return joinPoint;
    }

    public void setJoinPoint(JoinPoint joinPoint) {
        this.joinPoint = joinPoint;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public AlsAspectStrategy<T> getAlsAspectStrategy() {
        return alsAspectStrategy;
    }

    public void setAlsAspectStrategy(AlsAspectStrategy<T> alsAspectStrategy) {
        this.alsAspectStrategy = alsAspectStrategy;
    }

    public AlsContentJob<String, AlsAspectStrategy<T>> getAspectStrategyJob() {
        return aspectStrategyJob;
    }

    public void setAspectStrategyJob(AlsContentJob<String, AlsAspectStrategy<T>> aspectStrategyJob) {
        this.aspectStrategyJob = aspectStrategyJob;
    }

    public String getBaseProjectId() {
        return baseProjectId;
    }

    public void setBaseProjectId(String baseProjectId) {
        this.baseProjectId = baseProjectId;
    }
}
