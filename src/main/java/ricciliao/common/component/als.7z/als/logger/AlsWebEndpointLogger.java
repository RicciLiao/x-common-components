package ricciliao.common.component.als.logger;

import hk.health.medication.als.AlsBeanConfiguration;
import hk.health.medication.als.AlsLoggerRegistry;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

import javax.xml.bind.JAXBElement;

@Aspect
@AlsBeanConfiguration(name = AlsLoggerRegistry.BEAN_NAME_FOR_ALS_WEB_SERVICE_ENDPOINT_ASPECT)
public class AlsWebEndpointLogger extends AlsBaseAspect {

    public AlsWebEndpointLogger(AlsLoggerRegistry alsLoggerRegistry) {
        super(alsLoggerRegistry);
    }

    @Pointcut("execution(public * hk.health.*.webservice.*.*(..))" +
            "&&" +
            "@within(org.springframework.ws.server.endpoint.annotation.Endpoint)")
    public void pointCut() {
        // @Pointcut
    }

    @Before(value = "pointCut()")
    public void before(JoinPoint joinPoint) {
        super.getAlsLoggerAsyncService().info(new hk.health.medication.als.strategy.before.impl.AlsWebEndpointImpl(super.getAlsLoggerRegistry()).process(joinPoint, null));
    }

    @AfterReturning(pointcut = "pointCut()", returning = "returning")
    public void afterReturning(JoinPoint joinPoint, Object returning) {
        super.getAlsLoggerAsyncService().info(new hk.health.medication.als.strategy.after.returning.impl.AlsWebEndpointImpl(super.getAlsLoggerRegistry()).process(joinPoint, (JAXBElement) returning));
    }

    @AfterThrowing(pointcut = "pointCut()", throwing = "throwable")
    public void afterThrowing(JoinPoint joinPoint, Throwable throwable) {
        super.getAlsLoggerAsyncService().warn(new hk.health.medication.als.strategy.after.throwing.impl.AlsDefaultThrowingImpl(super.getAlsLoggerRegistry()).process(joinPoint, throwable));
    }

}
