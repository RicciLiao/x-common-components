package ricciliao.common.component.als.strategy.after.returning;

import hk.health.medication.als.AlsLoggerRegistry;
import hk.health.medication.als.common.AlsCommonHelper;
import hk.health.medication.als.common.AlsContent;
import hk.health.medication.als.common.AlsContentModeEnum;
import hk.health.medication.als.common.AlsEncryptionModeEnum;
import hk.health.medication.als.common.AlsLoggerUtil;
import hk.health.medication.als.pojo.AlsContentJobBo;
import hk.health.medication.als.pojo.AlsStrategyBo;
import hk.health.medication.als.strategy.AlsAspectStrategy;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.reflect.MethodSignature;

public abstract class AlsControllerStrategy<T> extends AlsReturningStrategy<T> {

    public AlsControllerStrategy(AlsLoggerRegistry alsLoggerRegistry) {
        super(alsLoggerRegistry);
    }

    @Override
    protected String getContent(AlsStrategyBo alsStrategy, JoinPoint joinPoint, T data) {
        AlsContent alsContent = ((MethodSignature) joinPoint.getSignature()).getMethod().getAnnotation(AlsContent.class);
        AlsEncryptionModeEnum alsEncryptionModeEnum = alsContent != null ? alsContent.isResponseEncrypted() : AlsEncryptionModeEnum.DEFAULT;
        boolean isEncrypted = AlsEncryptionModeEnum.DEFAULT.equals(alsEncryptionModeEnum) ? AlsLoggerUtil.isResponseEncrypted() : AlsEncryptionModeEnum.CIPHERED.equals(alsEncryptionModeEnum);
        AlsContentModeEnum alsContentModeEnum = alsContent != null ? alsContent.responseMode() : AlsContentModeEnum.BASE_INFO_OR_TOKEN_MODE;

        return AlsCommonHelper.alsContentJob(
                new AlsContentJobBo<>(alsStrategy, joinPoint, data, this,
                        (AlsAspectStrategy<T> alsAspectStrategy) -> this.getMethodReturning(alsStrategy, data),
                        super.getAlsLoggerRegistry().getBaseProjectId()
                ), isEncrypted, alsContentModeEnum
        );
    }

}
