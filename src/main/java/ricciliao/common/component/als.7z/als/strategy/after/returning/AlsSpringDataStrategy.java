package ricciliao.common.component.als.strategy.after.returning;

import hk.health.medication.als.AlsLoggerRegistry;
import hk.health.medication.als.common.AlsCommonHelper;
import hk.health.medication.als.common.AlsConstant;
import hk.health.medication.als.pojo.AlsStrategyBo;
import org.apache.commons.collections4.CollectionUtils;
import org.aspectj.lang.JoinPoint;

import java.util.Collection;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Map;
import java.util.Optional;

public abstract class AlsSpringDataStrategy extends AlsReturningStrategy<Object> {

    public AlsSpringDataStrategy(AlsLoggerRegistry alsLoggerRegistry) {
        super(alsLoggerRegistry);
    }

    protected abstract String getQuery(JoinPoint joinPoint);

    @Override
    protected String getMethodDescription(AlsStrategyBo alsStrategy, JoinPoint joinPoint) {
        String[] signatureArr = joinPoint.getSignature().toString().split("\\.");

        return String.format(AlsConstant.ALS_BASE_DESCRIPTION_FORMAT_FOR_COMPLETED,
                super.getAlsLoggerRegistry().getBaseProjectId(),
                signatureArr[signatureArr.length - 2],
                signatureArr[signatureArr.length - 1],
                "");
    }

    @Override
    protected String getMethodReturning(AlsStrategyBo alsStrategy, Object data) {
        if (data instanceof Map
                || data instanceof Collection
                || data instanceof Iterable
                || data instanceof Object[]
                || data instanceof Iterator
                || data instanceof Enumeration) {

            return String.format(AlsConstant.ALS_BASE_RESULT_CONTENT_FORMAT, data.getClass().getSimpleName());
        }

        return String.format(AlsConstant.ALS_BASE_RESULT_CONTENT_FORMAT,
                AlsCommonHelper.objectToJsonString(data, super.getAlsLoggerRegistry().getObjectMapper()));
    }

    @Override
    protected String getContent(AlsStrategyBo alsStrategy, JoinPoint joinPoint, Object data) {
        String methodArgs = this.getMethodArgs(joinPoint);
        return new StringBuilder(String.format(AlsConstant.ALS_BASE_PARAMETERS_CONTENT_FORMAT, methodArgs))
                .append(this.getMethodReturning(alsStrategy, data))
                .append(this.getReturningSize(data))
                .append(this.getQuery(joinPoint)).toString();
    }

    @Override
    protected void destroy() {
        //do nothing
    }

    protected String getMethodArgs(JoinPoint joinPoint) {
        StringBuilder methodArgs = new StringBuilder();
        if (joinPoint.getArgs().length > 0) {
            for (Object arg : joinPoint.getArgs()) {
                methodArgs.append(AlsCommonHelper.objectToJsonString(arg, super.getAlsLoggerRegistry().getObjectMapper()));
                methodArgs.append(AlsConstant.ALS_GNU_SED);
            }

            return methodArgs.substring(0, methodArgs.length() - AlsConstant.ALS_GNU_SED.length());
        }

        return methodArgs.toString();
    }

    protected String getReturningSize(Object data) {
        try {
            if (data instanceof Optional && ((Optional) data).isPresent()) {

                return String.format(AlsConstant.ALS_STRUCTURED_QUERY_LANGUAGE_RESULT_COUNT, CollectionUtils.size(((Optional) data).get()));
            } else {

                return String.format(AlsConstant.ALS_STRUCTURED_QUERY_LANGUAGE_RESULT_COUNT, CollectionUtils.size(data));
            }
        } catch (IllegalArgumentException e) {

            return String.format(AlsConstant.ALS_STRUCTURED_QUERY_LANGUAGE_RESULT_COUNT, 1);
        }
    }

}
