package ricciliao.common.component.als.strategy.after.throwing.impl;

import hk.health.medication.als.AlsLoggerRegistry;
import hk.health.medication.als.common.AlsCommonHelper;
import hk.health.medication.als.common.AlsConstant;
import hk.health.medication.als.pojo.AlsStrategyBo;
import hk.health.medication.als.strategy.after.throwing.AlsThrowingStrategy;
import org.aspectj.lang.JoinPoint;

public class AlsDefaultThrowingImpl extends AlsThrowingStrategy {

    public AlsDefaultThrowingImpl(AlsLoggerRegistry alsLoggerRegistry) {
        super(alsLoggerRegistry);
    }

    @Override
    protected String getMethodDescription(AlsStrategyBo alsStrategy, JoinPoint joinPoint, Throwable throwable) {
        String desc;
        if (joinPoint.getSignature().toShortString().contains("BaseRepositoryImpl.findAll(..)")) {

            desc = String.format(AlsConstant.ALS_BASE_DESCRIPTION_FORMAT_FOR_EXCEPTION,
                    this.getAlsLoggerRegistry().getBaseProjectId(),
                    "BaseRepositoryImpl",
                    "findAll(" + ((Class) joinPoint.getArgs()[0]).getSimpleName() + ")");
        } else {
            String[] signatureArr = joinPoint.getSignature().toString().split("\\.");

            desc = String.format(AlsConstant.ALS_BASE_DESCRIPTION_FORMAT_FOR_EXCEPTION,
                    this.getAlsLoggerRegistry().getBaseProjectId(),
                    signatureArr[signatureArr.length - 2],
                    signatureArr[signatureArr.length - 1]);
        }

        return String.format(AlsConstant.ALS_BASE_DESCRIPTION_FORMAT_FOR_EXCEPTION_WITH_EXCEPTION_MESSAGE, desc, throwable.getMessage());
    }

    @Override
    protected String getThrowable(AlsStrategyBo alsStrategy, JoinPoint joinPoint, Throwable throwable) {

        return AlsCommonHelper.getThrowable(throwable);
    }

    @Override
    protected void destroy() {
        // do nothing
    }

}
