package ricciliao.common.component.als.logger;

import hk.health.medication.als.AlsBeanConfiguration;
import hk.health.medication.als.AlsLoggerRegistry;
import hk.health.medication.als.common.AlsLoggerUtil;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
@AlsBeanConfiguration(name = AlsLoggerRegistry.BEAN_NAME_FOR_ALS_JDBC_TEMPLATE_ASPECT)
public class AlsJdbcTemplateAspectLogger extends AlsBaseAspect {

    public AlsJdbcTemplateAspectLogger(AlsLoggerRegistry alsLoggerRegistry) {
        super(alsLoggerRegistry);
    }

    @Pointcut("execution(public java.util.List org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate" +
            ".query(java.lang.String, java.util.Map, org.springframework.jdbc.core.RowMapper))" +
            "||" +
            "execution(public int org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate" +
            ".update(java.lang.String, java.util.Map))" +
            "||" +
            "execution(public java.util.List org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate" +
            ".query(java.lang.String, org.springframework.jdbc.core.RowMapper))")
    public void namedParameterJdbcTemplate() {
        // @Pointcut for NamedParameterJdbcTemplate
    }

    @AfterReturning(pointcut = "namedParameterJdbcTemplate()", returning = "returning")
    public void afterReturningForNPJdbcTemplate(JoinPoint joinPoint, Object returning) {
        if (AlsLoggerUtil.isLoggingEnabled()) {
            super.getAlsLoggerAsyncService().info(new hk.health.medication.als.strategy.after.returning.impl.AlsNamedParameterJdbcTemplateImpl(super.getAlsLoggerRegistry()).process(joinPoint, returning));
        }
    }

    @AfterThrowing(pointcut = "namedParameterJdbcTemplate()", throwing = "throwable")
    public void afterThrowingForNPJdbcTemplate(JoinPoint joinPoint, Throwable throwable) {
        if (AlsLoggerUtil.isLoggingEnabled()) {
            super.getAlsLoggerAsyncService().critical(new hk.health.medication.als.strategy.after.throwing.impl.AlsDefaultThrowingImpl(super.getAlsLoggerRegistry()).process(joinPoint, throwable), throwable);
        }
    }

}
