package ricciliao.common.component.als.common;

public enum AlsEncryptionModeEnum {

    DEFAULT(1, "Use YML configuration instead"),
    PLAINTEXT(2, "Not Encrypt the ALS content"),
    CIPHERED(3, "Encrypt the ALS content");

    private int mode;
    private String description;

    AlsEncryptionModeEnum(int mode, String description) {
        this.mode = mode;
        this.description = description;
    }

    public int getMode() {
        return mode;
    }

    public String getDescription() {
        return description;
    }

}
