package ricciliao.common.component.als.common;


import hk.org.ha.service.app.audit.als.AlsLogger;
import hk.org.ha.service.app.audit.als.AlsLoggerFactory;
import hk.org.ha.service.app.audit.als.AlsMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AlsLoggerUtil {

    private static final Logger logger = LoggerFactory.getLogger(AlsLoggerUtil.class);

    private AlsLoggerUtil() {
        throw new IllegalStateException("Utility class");
    }

    private static boolean loggingEnabled = false;
    private static boolean contentFullMode = false;
    private static boolean requestEncrypted = false;
    private static boolean responseEncrypted = false;

    public static boolean isLoggingEnabled() {
        return loggingEnabled;
    }

    public static boolean isContentFullMode() {
        return contentFullMode;
    }
    
    public static boolean isRequestEncrypted() {
        return requestEncrypted;
    }

    public static boolean isResponseEncrypted() {
        return responseEncrypted;
    }

    public static void setRequestEncrypted(boolean requestEncrypted) {
        AlsLoggerUtil.requestEncrypted = requestEncrypted;
    }

    public static void setResponseEncrypted(boolean responseEncrypted) {
        AlsLoggerUtil.responseEncrypted = responseEncrypted;
    }

    public static void setContentFullMode(boolean contentFullMode) {
        AlsLoggerUtil.contentFullMode = contentFullMode;
    }

    public static void setLoggingEnabled(boolean loggingEnabled) {
        logger.info("setLoggingEnabled: {}", loggingEnabled);
        AlsLoggerUtil.loggingEnabled = loggingEnabled;
    }

    public static void critical(AlsMessage critical) {
        if (!loggingEnabled) {
            return;
        }
        critical.setLogType(AlsConstant.CRITICAL);
        critical.setEncryptFields("");
        logging(critical);
    }

    public static void warn(AlsMessage warn) {
        if (!loggingEnabled) {
            return;
        }
        warn.setLogType(AlsConstant.WARN);
        warn.setEncryptFields("");
        logging(warn);
    }

    public static void info(AlsMessage info) {
        if (!loggingEnabled) {
            return;
        }
        info.setLogType(AlsConstant.INFO);
        logging(info);
    }

    public static void audit(AlsMessage audit) {
        if (!loggingEnabled) {
            return;
        }
        audit.setLogType(AlsConstant.AUDIT);
        logging(audit);
    }

    public static void logging(AlsMessage alsMessage) {
        try {
            alsMessage.setProjectCode(AlsConstant.ALS_PROJECT_CODE);
            AlsLogger alsLogger = AlsLoggerFactory.newInstance();

            //
            boolean result = alsLogger.out(alsMessage);
            if (!result) {
                logger.error(AlsConstant.ALS_LOGGER_ERROR_MESSAGE);
            }

        } catch (Exception e) {
            if (logger.isErrorEnabled()) {
                logger.error(AlsConstant.ALS_LOGGER_ERROR_MESSAGE, e);
            }
        }
    }

}
