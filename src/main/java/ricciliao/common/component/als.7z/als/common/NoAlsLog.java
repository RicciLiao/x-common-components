package ricciliao.common.component.als.common;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Class and method level annotation to turn off automatic als logging in controller level. Please the logging detail please refer to AlsControllerAspect.java
 * Adding it to class or method disables als logging for it. Annotation on method takes precedence over that on class.
 * @author wayne
 *
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.METHOD, ElementType.TYPE})
public @interface NoAlsLog {

}
