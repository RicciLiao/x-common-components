package ricciliao.common.component.als.strategy.before.impl;

import hk.health.medication.als.AlsLoggerRegistry;
import hk.health.medication.als.common.AlsCommonHelper;
import hk.health.medication.als.common.AlsConstant;
import hk.health.medication.als.pojo.AlsStrategyBo;
import hk.health.medication.als.strategy.before.AlsBeforeStrategy;
import org.aspectj.lang.JoinPoint;
import org.springframework.web.util.UriComponentsBuilder;

public class AlsRestTemplateImpl extends AlsBeforeStrategy<Object> {

    public AlsRestTemplateImpl(AlsLoggerRegistry alsLoggerRegistry) {
        super(alsLoggerRegistry);
    }

    @Override
    protected String getMethodDescription(AlsStrategyBo alsStrategy, JoinPoint joinPoint) {

        return String.format(AlsConstant.ALS_BASE_DESCRIPTION_FORMAT_FOR_OUTBOUND_REQUEST,
                this.getAlsLoggerRegistry().getBaseProjectId(),
                UriComponentsBuilder.fromHttpUrl(joinPoint.getArgs()[0].toString()).build().getPath());
    }

    @Override
    protected String getMethodArgs(AlsStrategyBo alsStrategy, JoinPoint joinPoint) {
        StringBuilder content = new StringBuilder();
        if (joinPoint.getArgs().length > 0) {
            for (Object arg : joinPoint.getArgs()) {
                content.append(AlsCommonHelper.objectToJsonString(arg, super.getAlsLoggerRegistry().getObjectMapper()));
                content.append(AlsConstant.ALS_GNU_SED);
            }

            return String.format(AlsConstant.ALS_BASE_PARAMETERS_CONTENT_FORMAT,
                    content.substring(0, content.length() - AlsConstant.ALS_GNU_SED.length()));
        }

        return String.format(AlsConstant.ALS_BASE_PARAMETERS_CONTENT_FORMAT, content.toString());
    }

    @Override
    protected void destroy() {
        // do nothing
    }

}
