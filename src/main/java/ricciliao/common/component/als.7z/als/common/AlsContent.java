package ricciliao.common.component.als.common;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.METHOD, ElementType.TYPE})
public @interface AlsContent {

    AlsContentModeEnum requestMode();

    AlsContentModeEnum responseMode();

    AlsEncryptionModeEnum isRequestEncrypted() default AlsEncryptionModeEnum.DEFAULT;

    AlsEncryptionModeEnum isResponseEncrypted() default AlsEncryptionModeEnum.DEFAULT;

}
