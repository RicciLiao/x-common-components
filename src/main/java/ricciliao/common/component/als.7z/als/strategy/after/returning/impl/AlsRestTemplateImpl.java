package ricciliao.common.component.als.strategy.after.returning.impl;

import hk.health.medication.als.AlsLoggerRegistry;
import hk.health.medication.als.common.AlsCommonHelper;
import hk.health.medication.als.common.AlsConstant;
import hk.health.medication.als.pojo.AlsStrategyBo;
import hk.health.medication.als.strategy.after.returning.AlsReturningStrategy;
import org.aspectj.lang.JoinPoint;
import org.springframework.web.util.UriComponentsBuilder;

public class AlsRestTemplateImpl extends AlsReturningStrategy<Object> {

    public AlsRestTemplateImpl(AlsLoggerRegistry alsLoggerRegistry) {
        super(alsLoggerRegistry);
    }

    @Override
    protected String getMethodDescription(AlsStrategyBo alsStrategy, JoinPoint joinPoint) {

        return String.format(AlsConstant.ALS_BASE_DESCRIPTION_FORMAT_FOR_OUTBOUND_RESPONSE,
                this.getAlsLoggerRegistry().getBaseProjectId(),
                UriComponentsBuilder.fromHttpUrl(joinPoint.getArgs()[0].toString()).build().getPath());
    }

    @Override
    protected String getMethodReturning(AlsStrategyBo alsStrategy, Object data) {

        return String.format(AlsConstant.ALS_BASE_RESULT_CONTENT_FORMAT,
                AlsCommonHelper.objectToJsonString(data, super.getAlsLoggerRegistry().getObjectMapper()));
    }

    @Override
    protected void destroy() {
        // do nothing
    }

}
