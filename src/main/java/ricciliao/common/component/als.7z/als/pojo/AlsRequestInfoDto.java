package ricciliao.common.component.als.pojo;

import java.io.Serializable;

public class AlsRequestInfoDto implements Serializable {

    private static final long serialVersionUID = 5030772784315655540L;
    private String caseNo;
    private String encounterNo;
    private String pmiNo;
    private String docTypeCd;
    private String docNo;

    public String getCaseNo() {
        return caseNo;
    }

    public void setCaseNo(String caseNo) {
        this.caseNo = caseNo;
    }

    public String getEncounterNo() {
        return encounterNo;
    }

    public void setEncounterNo(String encounterNo) {
        this.encounterNo = encounterNo;
    }

    public String getPmiNo() {
        return pmiNo;
    }

    public void setPmiNo(String pmiNo) {
        this.pmiNo = pmiNo;
    }

    public String getDocTypeCd() {
        return docTypeCd;
    }

    public void setDocTypeCd(String docTypeCd) {
        this.docTypeCd = docTypeCd;
    }

    public String getDocNo() {
        return docNo;
    }

    public void setDocNo(String docNo) {
        this.docNo = docNo;
    }
}
