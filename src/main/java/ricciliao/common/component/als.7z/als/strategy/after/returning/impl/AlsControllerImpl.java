package ricciliao.common.component.als.strategy.after.returning.impl;

import hk.health.medication.als.AlsLoggerRegistry;
import hk.health.medication.als.common.AlsCommonHelper;
import hk.health.medication.als.common.AlsConstant;
import hk.health.medication.als.pojo.AlsStrategyBo;
import hk.health.medication.als.strategy.after.returning.AlsControllerStrategy;
import org.aspectj.lang.JoinPoint;

public class AlsControllerImpl extends AlsControllerStrategy<Object> {

    public AlsControllerImpl(AlsLoggerRegistry alsLoggerRegistry) {
        super(alsLoggerRegistry);
    }

    @Override
    protected String getMethodDescription(AlsStrategyBo alsStrategy, JoinPoint joinPoint) {

        String[] signatureArr = joinPoint.getSignature().toString().split("\\.");

        return String.format(AlsConstant.ALS_BASE_DESCRIPTION_FORMAT_FOR_INBOUND_COMPLETED,
                super.getAlsLoggerRegistry().getBaseProjectId(),
                signatureArr[signatureArr.length - 2],
                signatureArr[signatureArr.length - 1],
                "");
    }

    @Override
    protected String getMethodReturning(AlsStrategyBo alsStrategy, Object data) {

        return String.format(AlsConstant.ALS_BASE_RESULT_CONTENT_FORMAT,
                AlsCommonHelper.objectToJsonString(data, super.getAlsLoggerRegistry().getObjectMapper()));
    }

    @Override
    protected void destroy() {
        AlsCommonHelper.removeAlsTraceByCurrentThread(super.getAlsLoggerRegistry());
    }

}
