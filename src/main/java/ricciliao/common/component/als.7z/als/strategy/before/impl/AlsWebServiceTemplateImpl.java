package ricciliao.common.component.als.strategy.before.impl;

import hk.health.medication.als.AlsLoggerRegistry;
import hk.health.medication.als.common.AlsCommonHelper;
import hk.health.medication.als.common.AlsConstant;
import hk.health.medication.als.pojo.AlsStrategyBo;
import hk.health.medication.als.strategy.before.AlsBeforeStrategy;
import org.aspectj.lang.JoinPoint;

import javax.xml.bind.JAXBElement;

public class AlsWebServiceTemplateImpl extends AlsBeforeStrategy<JAXBElement<Object>> {

    public AlsWebServiceTemplateImpl(AlsLoggerRegistry alsLoggerRegistry) {
        super(alsLoggerRegistry);
    }

    @Override
    protected String getMethodDescription(AlsStrategyBo alsStrategy, JoinPoint joinPoint) {

        return String.format(AlsConstant.ALS_BASE_DESCRIPTION_FORMAT_FOR_OUTBOUND_WS_REQUEST,
                super.getAlsLoggerRegistry().getBaseProjectId(),
                ((JAXBElement) joinPoint.getArgs()[0]).getName().getLocalPart());
    }

    @Override
    protected String getMethodArgs(AlsStrategyBo alsStrategy, JoinPoint joinPoint) {
        StringBuilder content = new StringBuilder();
        if (joinPoint.getArgs().length > 0) {
            for (Object arg : joinPoint.getArgs()) {
                content.append(AlsCommonHelper.jaxbToXmlString((JAXBElement<Object>) arg));
                content.append(AlsConstant.ALS_GNU_SED);
            }

            return String.format(AlsConstant.ALS_BASE_PARAMETERS_CONTENT_FORMAT,
                    content.substring(0, content.length() - AlsConstant.ALS_GNU_SED.length()));
        }

        return String.format(AlsConstant.ALS_BASE_PARAMETERS_CONTENT_FORMAT, content.toString());
    }

    @Override
    protected void destroy() {
        // do nothing
    }

}
