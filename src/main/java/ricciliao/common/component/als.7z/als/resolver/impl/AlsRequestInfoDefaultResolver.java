package ricciliao.common.component.als.resolver.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import hk.health.medication.als.common.AlsConstant;
import hk.health.medication.als.pojo.AlsRequestInfoDto;
import hk.health.medication.als.resolver.AlsRequestInfoResolver;
import hk.health.medication.common.CommonHelper;
import hk.health.medication.context.HttpContextUtil;

import javax.servlet.http.HttpServletRequest;

public class AlsRequestInfoDefaultResolver implements AlsRequestInfoResolver {

    @Override
    public AlsRequestInfoDto resolve(ObjectMapper objectMapper) {
        HttpServletRequest httpServletRequest = HttpContextUtil.getHttpServletRequest();
        String caseNo =
                CommonHelper.blankStrSelector(httpServletRequest.getHeader(AlsConstant.HTTP_HEADER_CASE_NO), "");
        String encounterNo =
                CommonHelper.blankStrSelector(httpServletRequest.getHeader(AlsConstant.HTTP_HEADER_ENCOUNTER_NO), "");
        String pmiNo =
                CommonHelper.blankStrSelector(httpServletRequest.getHeader(AlsConstant.HTTP_HEADER_PMI_NO), "");
        String docTypeCd =
                CommonHelper.blankStrSelector(httpServletRequest.getHeader(AlsConstant.HTTP_HEADER_PATIENT_DOC_TYPE_CD), "");
        String docNo =
                CommonHelper.blankStrSelector(httpServletRequest.getHeader(AlsConstant.HTTP_HEADER_PATIENT_DOC_NO), "");

        AlsRequestInfoDto alsRequestDto = new AlsRequestInfoDto();
        alsRequestDto.setCaseNo(caseNo);
        alsRequestDto.setEncounterNo(encounterNo);
        alsRequestDto.setPmiNo(pmiNo);
        alsRequestDto.setDocTypeCd(docTypeCd);
        alsRequestDto.setDocNo(docNo);

        return alsRequestDto;
    }
}
