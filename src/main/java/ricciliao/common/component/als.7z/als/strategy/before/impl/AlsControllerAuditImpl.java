package ricciliao.common.component.als.strategy.before.impl;

import hk.health.medication.als.AlsLoggerRegistry;
import hk.health.medication.als.common.AlsConstant;
import hk.health.medication.als.pojo.AlsStrategyBo;
import hk.health.medication.als.strategy.before.AlsControllerStrategy;
import hk.health.medication.common.CommonHelper;
import org.aspectj.lang.JoinPoint;

public class AlsControllerAuditImpl extends AlsControllerStrategy<Object> {

    public AlsControllerAuditImpl(AlsLoggerRegistry alsLoggerRegistry) {
        super(alsLoggerRegistry);
    }

    @Override
    protected AlsStrategyBo initiate() {
        AlsStrategyBo alsStrategyAudit = super.initiate();
        alsStrategyAudit.getAlsMessage().setFunctionId(alsStrategyAudit.getAlsTrace().getFunctionCode());

        return alsStrategyAudit;
    }

    @Override
    protected String getMethodDescription(AlsStrategyBo alsStrategy, JoinPoint joinPoint) {
        String extraDesc = CommonHelper.isBlank(alsStrategy.getAlsTrace().getPmiNoForHttp()) ?
                AlsConstant.ALS_BASE_DESCRIPTION_FORMAT_FOR_EXTRA_POINT : String.format(AlsConstant.ALS_BASE_DESCRIPTION_FORMAT_FOR_EXTRA_PMI, alsStrategy.getAlsTrace().getPmiNoForHttp());
        String[] signatureArr = joinPoint.getSignature().toString().split("\\.");

        return String.format(AlsConstant.ALS_AUDIT_DESCRIPTION_FORMAT_FOR_INBOUND_RECEIVED,
                alsStrategy.getAlsTrace().getFunctionName(),
                alsStrategy.getAlsTrace().getFrontendAction(),
                signatureArr[signatureArr.length - 2],
                signatureArr[signatureArr.length - 1],
                extraDesc);
    }

    @Override
    protected void destroy() {
        // do nothing
    }

}
