package ricciliao.common.component.als.strategy.after.returning.impl;

import hk.health.medication.als.AlsLoggerRegistry;
import hk.health.medication.als.common.AlsConstant;
import hk.health.medication.als.strategy.after.returning.AlsSpringDataStrategy;
import org.aspectj.lang.JoinPoint;

public class AlsNamedParameterJdbcTemplateImpl extends AlsSpringDataStrategy {

    public AlsNamedParameterJdbcTemplateImpl(AlsLoggerRegistry alsLoggerRegistry) {
        super(alsLoggerRegistry);
    }

    @Override
    protected String getQuery(JoinPoint joinPoint) {

        return String.format(AlsConstant.ALS_STRUCTURED_QUERY_LANGUAGE_DESC, joinPoint.getArgs()[0]);
    }

    @Override
    protected void destroy() {
        // do nothing
    }


}
