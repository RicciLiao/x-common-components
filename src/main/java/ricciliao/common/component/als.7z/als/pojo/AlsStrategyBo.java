package ricciliao.common.component.als.pojo;

import hk.org.ha.service.app.audit.als.AlsMessage;

public class AlsStrategyBo {

    public AlsStrategyBo(AlsTraceBo alsTrace, AlsMessage alsMessage) {
        this.alsTrace = alsTrace;
        this.alsMessage = alsMessage;
    }

    private final AlsTraceBo alsTrace;
    private final AlsMessage alsMessage;

    public AlsTraceBo getAlsTrace() {
        return alsTrace;
    }

    public AlsMessage getAlsMessage() {
        return alsMessage;
    }

}
