package ricciliao.common.component.als.strategy.after.returning;

import hk.health.medication.als.AlsLoggerRegistry;
import hk.health.medication.als.pojo.AlsStrategyBo;
import hk.health.medication.als.strategy.AlsAspectStrategy;
import org.aspectj.lang.JoinPoint;

public abstract class AlsReturningStrategy<T> extends AlsAspectStrategy<T> {

    public AlsReturningStrategy(AlsLoggerRegistry alsLoggerRegistry) {
        super(alsLoggerRegistry);
    }

    protected abstract String getMethodDescription(AlsStrategyBo alsStrategy, JoinPoint joinPoint);

    protected abstract String getMethodReturning(AlsStrategyBo alsStrategy, T data);

    @Override
    protected String getDescription(AlsStrategyBo alsStrategy, JoinPoint joinPoint, T data) {
        return this.getMethodDescription(alsStrategy, joinPoint);
    }

    @Override
    protected String getContent(AlsStrategyBo alsStrategy, JoinPoint joinPoint, T data) {

        return this.getMethodReturning(alsStrategy, data);
    }

}
