package ricciliao.common.component.als;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import hk.health.medication.als.logger.AlsBaseAspect;
import hk.health.medication.als.logger.AlsSpringDataRepoAspectLogger;
import hk.health.medication.als.resolver.AlsRequestInfoResolver;
import hk.health.medication.als.resolver.impl.AlsRequestInfoDefaultResolver;
import hk.health.medication.als.strategy.after.returning.AlsSpringDataStrategy;
import org.apache.commons.lang3.ArrayUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.config.ConstructorArgumentValues;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.beans.factory.support.GenericBeanDefinition;
import org.springframework.context.annotation.ImportBeanDefinitionRegistrar;
import org.springframework.core.type.AnnotationMetadata;

import java.lang.reflect.InvocationTargetException;
import java.util.Map;
import java.util.TimeZone;

public class AlsImporter implements ImportBeanDefinitionRegistrar {

    private static final Logger logger = LoggerFactory.getLogger(AlsImporter.class);

    public static final String BASE_PROJECT_ID = "baseProjectId";
    public static final String ASPECT_LOGGERS = "aspectLoggers";
    public static final String ALS_REQUEST_INFO_RESOLVER = "alsRequestInfoResolver";
    public static final String JSON_SERIALIZERS = "jsonSerializers";
    public static final String ALS_SPRING_DATA_STRATEGY = "alsSpringDataStrategy";

    @Override
    public void registerBeanDefinitions(AnnotationMetadata annotationMetadata, BeanDefinitionRegistry beanDefinitionRegistry) {
        Map<String, Object> alsImportAttributes = annotationMetadata.getAnnotationAttributes(AlsImport.class.getName());
        String baseProjectId = alsImportAttributes.get(BASE_PROJECT_ID) != null ?
                alsImportAttributes.get(BASE_PROJECT_ID).toString() : "";
        Class<? extends AlsBaseAspect>[] aspectLoggers = alsImportAttributes.get(ASPECT_LOGGERS) != null ?
                (Class[]) alsImportAttributes.get(ASPECT_LOGGERS) : new Class[0];
        Class<? extends AlsRequestInfoResolver> alsRequestResolver =
                (Class<? extends AlsRequestInfoResolver>) alsImportAttributes.get(ALS_REQUEST_INFO_RESOLVER);
        Class<? extends JsonSerializer>[] jsonSerializers = alsImportAttributes.get(ASPECT_LOGGERS) != null ?
                (Class[]) alsImportAttributes.get(JSON_SERIALIZERS) : new Class[0];
        Class<? extends AlsSpringDataStrategy> alsSpringDataStrategy =
                (Class<? extends AlsSpringDataStrategy>) alsImportAttributes.get(ALS_SPRING_DATA_STRATEGY);

        //Initialization AlsRequestInfoResolver start --
        AlsRequestInfoResolver alsRequestInfoResolverInstance;
        try {
            alsRequestInfoResolverInstance = alsRequestResolver.getConstructor().newInstance();
        } catch (InstantiationException
                 | IllegalAccessException
                 | InvocationTargetException
                 | NoSuchMethodException e) {
            alsRequestInfoResolverInstance = new AlsRequestInfoDefaultResolver();
        }

        //Initialization Jackson start --
        ObjectMapper jacksonMapper = new ObjectMapper();
        jacksonMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        jacksonMapper.setTimeZone(TimeZone.getTimeZone("GMT+8"));
        jacksonMapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        jacksonMapper.registerModule(new JavaTimeModule());
        jacksonMapper.registerModule(new Jdk8Module());
        jacksonMapper.setAnnotationIntrospector(new AlsAnnotationIntrospector());
        if (ArrayUtils.isNotEmpty(jsonSerializers)) {
            SimpleModule customModule = new SimpleModule();
            for (Class<? extends JsonSerializer> jsonSerializer : jsonSerializers) {
                try {
                    customModule.addSerializer(jsonSerializer.getConstructor().newInstance());
                } catch (InstantiationException
                         | IllegalAccessException
                         | InvocationTargetException
                         | NoSuchMethodException e) {
                    AlsLoggerFactory.getAlsGeneralLogger().critical(e.getMessage());
                    if (logger.isErrorEnabled()) {
                        logger.error("", e);
                    }
                }
            }
            jacksonMapper.registerModule(customModule);
        }

        //Initialization AlsLoggerRegistry start --
        AlsLoggerRegistry alsLoggerRegistry = new AlsLoggerRegistry(baseProjectId, jacksonMapper, alsRequestInfoResolverInstance);

        //Initialization AlsGeneralLogger start --
        AlsLoggerFactory.buildAlsGeneralLogger(alsLoggerRegistry);

        ConstructorArgumentValues alsLoggerRegistryArg = new ConstructorArgumentValues();
        alsLoggerRegistryArg.addIndexedArgumentValue(0, alsLoggerRegistry);

        //Initialization AlsLoggerFactory start --
        beanDefinitionRegistry.registerBeanDefinition(
                AlsLoggerRegistry.BEAN_NAME_FOR_ALS_LOGGER_FACTORY,
                genericBeanDefinition(AlsLoggerFactory.class, alsLoggerRegistryArg)
        );

        //Initialization AlsAspectLogger start --
        for (Class<? extends AlsBaseAspect> aspectLogger : aspectLoggers) {
            AlsBeanConfiguration alsBeanConfiguration = aspectLogger.getAnnotation(AlsBeanConfiguration.class);
            if (aspectLogger.equals(AlsSpringDataRepoAspectLogger.class)) {
                beanDefinitionRegistry.registerBeanDefinition(
                        alsBeanConfiguration.name(),
                        genericBeanDefinition(
                                (Class<? extends AlsSpringDataRepoAspectLogger>) aspectLogger,
                                alsLoggerRegistry,
                                alsSpringDataStrategy)
                );
            } else {
                beanDefinitionRegistry.registerBeanDefinition(
                        alsBeanConfiguration.name(),
                        genericBeanDefinition(aspectLogger, alsLoggerRegistryArg)
                );
            }
        }
    }

    private GenericBeanDefinition genericBeanDefinition(Class<? extends AlsSpringDataRepoAspectLogger> beanClass,
                                                        AlsLoggerRegistry alsLoggerRegistry,
                                                        Class<? extends AlsSpringDataStrategy> alsSpringDataStrategyClass) {
        ConstructorArgumentValues constructorArgumentValues = new ConstructorArgumentValues();
        constructorArgumentValues.addIndexedArgumentValue(0, alsLoggerRegistry);
        constructorArgumentValues.addIndexedArgumentValue(1, alsSpringDataStrategyClass);

        return genericBeanDefinition(beanClass, constructorArgumentValues);
    }

    private GenericBeanDefinition genericBeanDefinition(Class<?> beanClass,
                                                        ConstructorArgumentValues constructorArgumentValues) {
        GenericBeanDefinition genericBeanDefinition = new GenericBeanDefinition();
        genericBeanDefinition.setBeanClass(beanClass);
        genericBeanDefinition.setSynthetic(true);
        genericBeanDefinition.setConstructorArgumentValues(constructorArgumentValues);

        return genericBeanDefinition;
    }

}
