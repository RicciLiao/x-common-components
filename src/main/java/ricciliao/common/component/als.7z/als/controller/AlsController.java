package ricciliao.common.component.als.controller;

import hk.health.medication.als.AlsLoggerRegistry;
import hk.health.medication.als.common.AlsCommonHelper;
import hk.health.medication.als.common.AlsContent;
import hk.health.medication.als.common.AlsContentModeEnum;
import hk.health.medication.als.common.AlsLoggerUtil;
import hk.health.medication.als.common.AlsMapUtil;
import hk.health.medication.als.common.NoAlsLog;
import hk.health.medication.response.CimsResponseVo;
import hk.health.medication.response.ResponseUtil;
import hk.health.medication.sam3.common.Sam3Constant;
import hk.org.ha.service.app.audit.als.AlsMessage;
import org.apache.commons.collections4.MapUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.Map;

@ResponseBody
@RequestMapping("/als")
public class AlsController {

    private final AlsLoggerRegistry alsLoggerRegistry;

    public AlsController(AlsLoggerRegistry alsLoggerRegistry) {
        this.alsLoggerRegistry = alsLoggerRegistry;
    }

    @GetMapping
    @AlsContent(requestMode = AlsContentModeEnum.BASE_INFO_OR_TOKEN_MODE, responseMode = AlsContentModeEnum.PAYLOAD_MODE)
    public CimsResponseVo<Boolean> log() {

        return ResponseUtil.initSuccessResultVO(Boolean.TRUE);
    }

    @PostMapping("/customize")
    @AlsContent(requestMode = AlsContentModeEnum.PAYLOAD_MODE, responseMode = AlsContentModeEnum.PAYLOAD_MODE)
    @NoAlsLog
    public CimsResponseVo<Boolean> customize(@RequestHeader(Sam3Constant.AUTH_HEADER_KEY) String token,
                                             @RequestBody Map<String, String> request) {
        if (MapUtils.isEmpty(request)) {
            return this.log();
        }

        try {
            AlsMessage alsMessage = new AlsMessage();
            AlsCommonHelper.setAlsTraceByCurrentThread(alsLoggerRegistry);
            AlsMapUtil.transferTrace(alsMessage, alsLoggerRegistry.getThreadIdAndAlsTraceMap());
            alsMessage.setLogType(request.get("logType"));
            alsMessage.setDescription(request.get("desc"));
            alsMessage.setEncryptFields(Boolean.TRUE.toString().equalsIgnoreCase(request.get("isEncrypt")) ? "CONTENT" : "");
            alsMessage.setContent(token);
            alsMessage.setPatientIdentity(request.get("pmi"));
            AlsLoggerUtil.logging(alsMessage);

            return ResponseUtil.initSuccessResultVO(Boolean.TRUE);
        } finally {
            AlsCommonHelper.removeAlsTraceByCurrentThread(alsLoggerRegistry);
        }
    }

}
